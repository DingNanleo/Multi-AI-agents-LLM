## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 166: Spontaneous Subarachnoid and Intracerebral Hemorrhage
Anna M. Nelson; Caitlin A. Mase; O. John Ma
INTRODUCTION
Although hemorrhagic strokes, including nontraumatic subarachnoid hemorrhages and intracerebral hemorrhages, account for a relatively small portion of ED visits, a missed diagnosis can produce devastating results. Early recognition and aggressive management may improve outcomes.
Hemorrhagic stroke accounts for 15% of all strokes and is classified according to the anatomic location of the bleed; nearly one third of hemorrhagic
 strokes are the subarachnoid type, whereas two thirds are from intracerebral hemorrhage.
Subarachnoid hemorrhage is the leakage of blood into the subarachnoid space and classically presents as a sudden, severe headache. Intracerebral hemorrhage, bleeding into the brain parenchyma itself, typically presents as an acute neurologic deficit, often accompanied by headache. The features and treatment of subarachnoid and intracerebral hemorrhage are discussed in this chapter. Management of intracerebral hemorrhage is very different from the management of ischemic stroke. Ischemic stroke is discussed in Chapter 167, “Stroke Syndromes.”
SUBARACHNOID HEMORRHAGE
EPIDEMIOLOGY

About 75% of atraumatic subarachnoid hemorrhages are caused by a ruptured aneurysm. In about 20% of cases a cause is not identified. The remaining causes are related to a variety of miscellaneous conditions, including arteriovenous malformations, sympathomimetic drugs, and other less common causes. About 20% of patients with one aneurysm will have an additional aneurysm, which makes identification of the initial aneurysm important.
Two percent of family members of patients with subarachnoid hemorrhage will develop the same disease. This risk rises with increasing number of
 family members involved or with a family history of adult polycystic kidney disease. Hypertension and smoking increase risk as well. Additional risk factors are listed in Table 166­1. TABLE 166­1
Risk Factors for Subarachnoid Hemorrhage
Hypertension
Smoking
Excessive alcohol consumption
Polycystic kidney disease
Family history of subarachnoid hemorrhage
Coarctation of the aorta
Marfan’s syndrome
Ehlers­Danlos syndrome type IV
α ­Antitrypsin deficiency

PATHOPHYSIOLOGY

Chapter 166: Spontaneous Subarachnoid and Intracerebral Hemorrhage, Anna M. Nelson; Caitlin A. Mase; O. John Ma 
Cerebral aneurysms are focal arterial pouches typically located in areas of bifurcation of the circle of Willis. While the precise pathophysiology is not
. Terms of Use * Privacy Policy * Notice * Accessibility known, many factors have been associated with aneurysmal development and rupture. Such factors include genetic predisposition, cellular
 aberrations in vascular wall repair or remodeling, and aberrations in local blood flow. While it is not possible to predict rupture risk of a particular
,4 aneurysm, larger aneurysms (>5 to  mm) are more likely to rupture than smaller aneurysms.
CLINICAL FEATURES
Patients with subarachnoid hemorrhage classically present to the ED with a severe headache of acute onset (termed a “thunderclap” headache) that
 reaches maximal intensity within seconds. Typically, the headache persists for several days but may resolve in a shorter period of time. Subarachnoid
,6 hemorrhage is diagnosed in 11% to 25% of patients who present to the ED with a thunderclap headache. Even if a patient is not experiencing the “worst headache of their life,” a headache that is different in intensity or quality from past headaches should raise concern for subarachnoid hemorrhage. Headaches associated with loss of consciousness, seizure, diplopia or other neurologic signs, or nuchal rigidity also
 require clinical investigation. Less frequently, patients may present with nausea and vomiting, altered mental status, photophobia, or symptoms suggestive of ischemic stroke. Approximately 20% of patients develop their symptoms while engaged in activities that cause increased blood pressure, such as exercise, sexual intercourse, or defecation.
DIAGNOSIS
Consider subarachnoid hemorrhage in the differential diagnosis for all patients presenting with a concerning headache. Subarachnoid hemorrhage can be ruled out with 100% sensitivity with implementation of the Ottawa Subarachnoid Hemorrhage Rule for headache evaluation. Although inclusion criteria are stringent, subarachnoid hemorrhage may be excluded in patients under  years of age, without neck pain or stiffness, without a witnessed loss of consciousness, without onset during exertion, without a thunderclap headache, and without
8­10 limited neck flexion. Misdiagnosis is associated with normal mental status (present in about half of patients with subarachnoid hemorrhage)
 and smaller size of hemorrhage. Up until recently, patients were believed to have worse outcomes if misdiagnosed, but this might not always be the case, and a careful evaluation for subarachnoid hemorrhage for patients who cannot be ruled out with the Ottawa subarachnoid hemorrhage rule is
11­14 still important. Complications of missed diagnosis include repeat hemorrhage and obstructive hydrocephalus. Symptomatic improvement
 following analgesics does not exclude life­threatening causes of headache. Table 166­2 lists the differential diagnosis of subarachnoid hemorrhage.
TABLE 166­2
Differential Diagnosis of Subarachnoid Hemorrhage
Vascular pathology (other intracranial hemorrhage, ischemic stroke or transient ischemic attack, arterial dissection, venous thrombosis)
Drug toxicity
Infection (meningitis, encephalitis)
Intracranial tumor
Intracranial hypotension
Metabolic derangements
Primary headache syndromes (benign thunderclap headache, migraine, cluster headache)
Hypertensive disorders
IMAGING
The initial diagnostic modality of choice when subarachnoid hemorrhage is suspected is a noncontrast CT of the head (Figures 166­1 and 166­2).
The sensitivity of CT in diagnosing subarachnoid hemorrhage is highest shortly after symptoms begin and is estimated to be 98% within  to  hours of symptom onset. In patients who are neurologically intact who present with a thunderclap headache, a normal head CT
 within  hours of headache onset is extremely sensitive in ruling out aneurysmal subarachnoid hemorrhage. Sensitivity decreases to about 91% to
,15
93% at  hours and continues to decline rapidly thereafter, reaching 50% at  week. Newer­generation CT scanners are even more sensitive for detecting subarachnoid hemorrhage, especially in the setting of (1) patients presenting within  hours of symptom onset, and (2) greater availability of
17­19 a timely interpretation by a neuroradiologist.
FIGURE 166­1. Diffuse subarachnoid hemorrhage with associated ventricular hemorrhage. Top arrow indicates blood in interhemispheric fissure. Bottom arrow indicates blood in lateral ventricle. [Image used with permission of James Anderson, MD, Department of Radiology, Oregon Health & Science
University.]
FIGURE 166­2. Scattered subarachnoid hemorrhages (arrows). [Image used with permission of James Anderson, MD, Department of Radiology, Oregon Health &
Science University.]
CT angiography and MRI or magnetic resonance angiography are options after a negative head CT, when these studies are clinically appropriate and
 available. In a small study, two of 116 patients had an aneurysm discovered by CT angiography after normal findings on both CT and lumbar
  puncture. The probability of correctly excluding a subarachnoid hemorrhage following CT/CT angiography is about .4%. One of the consequences of this diagnostic pathway is the detection of incidental aneurysms that may prompt unnecessary intervention, with the background incidence of aneurysms in the population (2% to 6%) exceeding that of the morbidity and mortality associated with subarachnoid hemorrhages, as well
 as the ionizing radiation. Current clinical practice has moved toward ruling out subarachnoid hemorrhages in patients with a normal CT/CT angiography so long as they present within  hours of symptom onset. The option for obtaining a lumbar puncture in patients in whom there is still a strong suspicion of subarachnoid hemorrhage, despite negative imaging studies, remains a method for complete evaluation.

The usefulness of MRI, particularly fluid­attenuated inversion recovery MRI sequences, is limited. A negative MRI result still needs to be followed by a
 lumbar puncture.
LUMBAR PUNCTURE
,27
Most authorities recommend cerebrospinal fluid (CSF) analysis when a patient with suspected subarachnoid hemorrhage has a normal head CT.
Another advantage of lumbar puncture is the ability to identify other causes of headache, such as meningitis or idiopathic intracranial hypertension.
The main disadvantage of lumbar puncture includes post–lumbar puncture headache and other discomfort for the patient; a lumbar puncture may be contraindicated in the patient with coagulopathy or thrombocytopenia.
The two CSF tests of greatest interest are the presence of xanthochromia and red blood cell (RBC) count. Xanthochromia is a yellow appearance of the
CSF due to the enzymatic breakdown of blood releasing bilirubin. Any exposure of the CSF to light prior to interpretation can increase the rate of
 bilirubin degradation, which decreases any xanthochromia present. Similarly, a delay in processing the CSF specimen may result in the development of xanthochromia following a traumatic lumbar puncture. CSF is evaluated for xanthochromia with visual inspection, the standard technique in most

U.S. laboratories, or by spectrophotometry, which may have superior sensitivity but only 75% specificity, resulting in false positives. The utility of the
 test is further limited in that it takes approximately  hours from hemorrhage onset for xanthochromia to develop in CSF.
The RBC count in the third or fourth tube of CSF is commonly used to identify subarachnoid hemorrhage. The number of RBCs that constitutes a positive lumbar puncture result has never been clearly defined, nor has the number of RBCs that may be attributed to a traumatic lumbar puncture.

One study demonstrated that approximately 10% to 15% of lumbar punctures are traumatic, using cutoffs of 400 and 1000 RBCs, respectively. A comparison of cell counts between consecutive tubes or between tubes  and  is sometimes used to differentiate subarachnoid hemorrhage from a traumatic lumbar puncture. One small study, however, demonstrated that a 25% reduction in RBCs between tubes  and  may occur even in cases of
 confirmed subarachnoid hemorrhage. Another small study found that RBCs <100 in the final tube effectively ruled out subarachnoid hemorrhage,
 whereas an RBC count of >10,000 in the final tube was associated with an increase in the odds of subarachnoid hemorrhage by a factor of . Unfortunately, the literature remains unclear on the precise threshold number of RBCs needed in the CSF to be considered diagnostic of subarachnoid hemorrhage.

In general, normal findings on head CT, the absence of xanthochromia, and zero or few RBCs (<5 ×  RBCs/L) in the CSF help reliably exclude
 subarachnoid hemorrhage. A normal head CT result with a positive finding of xanthochromia or elevated RBC count in tube  should be considered diagnostic of subarachnoid hemorrhage.
SUBARACHNOID HEMORRHAGE GRADING SCALES
Many different subarachnoid hemorrhage grading scales exist. Those most widely used include the Hunt and Hess scale and the World Federation of
Neurosurgical Societies scale (Table 166­3). A higher grade on either scale indicates a higher likelihood of poor outcome.
TABLE 166­3
Grading Scales for Subarachnoid Hemorrhage
Grade Hunt and Hess Scale World Federation of Neurosurgical Societies Scale
 Mild headache, normal mental status, no cranial nerve or motor findings GCS of , no motor deficits
 Severe headache, normal mental status, may have cranial nerve deficit GCS of  or , no motor deficits
 Somnolent, confused, may have cranial nerve or mild motor deficit GCS of  or , with motor deficits
 Stupor, moderate to severe motor deficit, may have intermittent reflex posturing GCS of 7–12, with or without motor deficits
 Coma, reflex posturing or flaccid GCS of 3–6, with or without motor deficits
Abbreviation: GCS = Glasgow Coma Scale score.
Source: Reproduced with permission from Hemphill JC: Neurologic critical care, in Fauci AS, Braunwald E, Kasper DL, et al (eds): Harrison’s Principles of Internal
Medicine, 17th ed. © McGraw­Hill, Inc., New York, 2008. TREATMENT
Medical management of the subarachnoid hemorrhage patient in the ED should occur in a monitored critical care area and should target the prevention of complications. Reassess the Glasgow Coma Scale and pupillary responses regularly because a decrease of  Glasgow Coma Scale point
 may indicate the onset of complications. Intracerebral and extracerebral complications of subarachnoid hemorrhage include rebleeding, vasospasm, cerebral infarction, cerebral edema, hydrocephalus, intracranial hypertension, fluid status and electrolyte abnormalities, respiratory failure,
 myocardial dysfunction, thromboembolism, and sepsis.
The risk of rebleeding is greatest in the first  to  hours and can be reduced by adequate blood pressure control. Control blood pressure with a titratable agent to balance the risk of stroke, hypertension­related rebleeding, and maintenance of cerebral perfusion pressure. While target pressures have not yet been established, a decrease in systolic blood pressure to a range of 120 to

160 mm Hg is reasonable. Because blood pressure may fluctuate through the course of the disease, a titratable IV antihypertensive is preferred.
Labetalol and nicardipine are often used, with neither demonstrating clear superiority. Avoid nitroprusside and nitroglycerin because they
35­37 increase cerebral blood volume and intracranial pressure. There is debate regarding the use of antifibrinolytics to prevent rebleeding after
 subarachnoid hemorrhage, with weak evidence supporting short­ but not long­term use in the first  days. Generally, antifibrinolytics are not used
 because there is a risk of increased cerebral ischemia, as well as other dangerous complications. However, in scenarios where there is an unavoidable delay in aneurysm obliteration, significant risk of rebleeding, and no major contraindications, initiation of tranexamic acid or aminocaproic acid in the ED is reasonable to reduce the risk of early aneurysm rebleeding, but should be done only in consultation with the accepting
 neurosurgeon given high complication rates. Pain medications and antiemetics are also critical adjuncts in maintaining the alert patient’s comfort and blood pressure.
Vasospasm is most common  days to  weeks after subarachnoid hemorrhage. A modest protective benefit is seen with administration of nimodipine,  milligrams PO every  hours, and this therapy should be initiated within  hours of symptom onset unless contraindicated due to allergy, nonfunctioning GI tract, or hepatic disease. Clinical trials of other novel treatments, including statins, magnesium, and endothelin receptor
39­43 antagonist, have not demonstrated significant reductions in mortality.
Delayed cerebral ischemia is associated with hypothermia, hyperthermia, and hyperglycemia. Prevent these conditions with the appropriate use of warming or cooling blankets, antipyretics, or insulin as indicated.
Approximately 5% to 20% of patients with subarachnoid hemorrhage have at least one seizure. Consideration of seizure prophylaxis is currently supported by several clinical guidelines; however, this topic remains controversial and should be determined in conjunction with the intensivist or
 neurosurgeon who will manage the patient.
DISPOSITION AND FOLLOW­UP
Admit all patients diagnosed with subarachnoid hemorrhage to an intensive care unit in consultation with a neurosurgeon. In patients with normal findings on head CT and CSF analysis within  weeks of occurrence of initial headache symptoms, another explanation for symptoms should be
,45 pursued; these patients may be safe for discharge from the ED. Consider consultation with a neurosurgeon for patients who present >2 weeks after
 the sudden onset of a severe headache causing suspicion for subarachnoid hemorrhage if the initial workup yields normal findings.
INTRACEREBRAL HEMORRHAGE
EPIDEMIOLOGY
Spontaneous intracerebral hemorrhage causes 8% to 11% of all acute strokes and is twice as common as subarachnoid hemorrhage. Like subarachnoid hemorrhage, intracerebral hemorrhage carries a high morbidity and mortality. Seven­day mortality is approximately 30%, 1­year
 mortality about 55%, and 10­year mortality approximately 80%. Among those who survive, only one in five will be functionally independent at  year.
Intracerebral hemorrhage occurs greater than two times more frequently in blacks than in whites, which may be related to the higher prevalence of
 hypertension in blacks. Additionally, intracerebral hemorrhage occurs in approximately 3% to 9% of patients treated with tissue plasminogen
 activator for acute ischemic stroke.
The effect on intracerebral hemorrhage of both novel oral anticoagulants and vitamin K antagonists such as warfarin when used for atrial fibrillation to prevent ischemic stroke has been at the center of much debate and research. Overall, poorer outcomes have been observed in patients taking
,48 anticoagulants, whether novel oral anticoagulants or vitamin K antagonists, who develop intracerebral hemorrhage. Importantly, novel oral anticoagulants are associated with reduced risk of intracerebral hemorrhage when compared to warfarin when used for stroke prevention in atrial
 fibrillation. Anticoagulation with warfarin is a significant risk factor for intracerebral hemorrhage, with an annual intracerebral hemorrhage incidence of .3% to .6% in those taking the drug, and warfarin plays a role in 6% to 16% of all cases of intracerebral hemorrhage. Among patients taking warfarin, the risk of intracerebral hemorrhage nearly doubles for each .5 increase in international normalized ratio above .5. When comparing novel oral anticoagulant–associated intracerebral hemorrhage with vitamin K antagonist–associated intracerebral hemorrhage, more research is needed. One pooled analysis reports that intracerebral hemorrhage volume, 90­day mortality, and functional outcomes are similar
 following both novel oral anticoagulant– and vitamin K antagonist–associated intracerebral hemorrhage, whereas another prospective review and meta­analysis demonstrated that novel oral anticoagulant–associated intracerebral hemorrhage is associated with smaller baseline hematoma
 volume and lesser neurologic deficit at time of hospital admission when compared to vitamin K antagonist–associated intracerebral hemorrhage. As more patients are being transitioned to novel oral anticoagulants, one study demonstrated that of patients who sustain intracerebral hemorrhage, in­
,53 hospital mortality is lower for those on novel oral anticoagulants as compared with those on vitamin K antagonists.
PATHOPHYSIOLOGY
Risk factors for intracerebral hemorrhage include long­standing hypertension, arteriovenous malformations, arterial aneurysm, anticoagulant therapy, use of sympathomimetic drugs (particularly cocaine and phenylpropanolamine), intracranial tumors, and amyloid angiopathy in the elderly.
Current smoking and increased frequency of smoking also raise the risk of intracerebral hemorrhage, but the etiology of this increased risk is not as
 well defined as in ischemic stroke.
CLINICAL FEATURES
Intracerebral hemorrhage may be clinically indistinguishable from cerebral infarction, subarachnoid hemorrhage, and ischemic stroke. In intracerebral hemorrhage, headache, nausea, and vomiting often precede the neurologic deficit, and in contrast to subarachnoid hemorrhage, the headache onset is usually more insidious. In hypertensive intracerebral hemorrhage, bleeding is usually localized to the putamen, thalamus, pons, or cerebellum (in decreasing order of frequency), and clinical examination findings may be relatable to those areas. Cerebellar hemorrhage is commonly associated with dizziness, vomiting, marked truncal ataxia, gaze palsies, and depressed level of consciousness. Patients with cerebellar hemorrhage are more likely to have rapidly progressive symptoms and may require more aggressive intervention than patients with other forms of intracerebral hemorrhage.
DIAGNOSIS AND IMAGING
The differential diagnosis of intracerebral hemorrhage is similar to that of subarachnoid hemorrhage. The history, rapidity of progression of symptoms, and other clinical features may suggest that intracerebral hemorrhage is more likely than subarachnoid hemorrhage or ischemic stroke, but these features are not adequate alone to make a clinical diagnosis. CT and MRI each have areas of superiority in evaluating a patient for intracerebral hemorrhage. CT is optimal for demonstrating hemorrhage extension into the ventricles, whereas MRI is superior for demonstrating underlying structural lesions. Either modality is considered acceptable as the initial study for diagnosing intracerebral
 hemorrhage. Widespread availability of CT and its short scan time make a noncontrast CT the initial study of choice in most EDs (Figure 166­3). The addition of contrast may allow identification of masses or aneurysms.
FIGURE 166­3. Large right­sided parietal intraparenchymal hemorrhage (arrow). [Image used with permission of James Anderson, MD, Department of Radiology,
Oregon Health & Science University.]
Cerebral angiography may be useful in selected patients in stable condition who do not require urgent surgery, particularly those in whom no obvious
 cause of bleeding is identified and those younger than  years of age without hypertension.
TREATMENT
Treat patients with intracerebral hemorrhage in a monitored critical care area. Patients with cerebellar hemorrhage are at particularly high risk of
,57 rapid deterioration and may require rapid intervention for surgical evacuation of hemorrhage. Maintain close attention to the patient’s airway and neurologic status. Reduce hyperthermia with antipyretics, administer antiepileptic medications if seizures occur, aggressively manage hypo­ or hyperglycemia (>160 milligrams/dL or .9 mmol/L), manage blood pressure, and reverse coagulopathy (if present). Manage elevated intracranial pressure by raising the head of the bed  degrees and providing appropriate analgesia and sedation. If more aggressive reduction of intracranial pressure is required—such as administration of osmotic diuretics or intubation with neuromuscular blockade and mild hyperventilation—invasive intracranial pressure monitoring is generally indicated. Corticosteroids should not be given for treatment of elevated ICP in intracerebral
 hemorrhage.

Current guidelines for blood pressure management are listed in Table 166­4. Importantly, the Antihypertensive Treatment of Acute Cerebral
Hemorrhage II study demonstrated treatment of participants with intracerebral hemorrhage to achieve a target systolic blood pressure
 of 110 to 139 mm Hg did not result in a lower rate of death or disability than standard reduction to a target of 140 to 179 mm Hg.
TABLE 166­4
Suggested Guidelines for Treating Elevated Blood Pressure in Spontaneous Intracranial Hemorrhage58
Clinical Circumstances Management
SBP >220 mm Hg Consider aggressive reduction of blood pressure with continuous IV infusion.
SBP 150–220 mm Hg Acute lowering of SBP to 140 mm Hg is safe and can be effective for improving functional outcome.
Abbreviation: SBP = systolic blood pressure.
REVERSE COAGULOPATHY
Given the complexity and variety of antiplatelet and anticoagulation agents in current use, institutional protocols should be available with clear algorithms listing the indications for, and dosing of, reversal agents (Table 166­5). If the coagulopathy is related to heparin use, administer protamine at approximately  milligram per 100 units of heparin, adjusting based on the time since the heparin was last given. For patients taking warfarin, provide reversal no matter what the value of the international normalized ratio. For further discussion, see Chapter 239, “Thrombotics and
Antithrombotics.” Several options exist for reversing warfarin­induced coagulopathy: vitamin K, fresh frozen plasma, recombinant factor VIIa, and prothrombin complex concentrates. Vitamin K,  to  milligrams IV, can fully reverse warfarin­induced anticoagulation, but the full effect takes  to

 hours to achieve, during which time the hematoma may continue to expand. Fresh frozen plasma has a faster onset, but contains variable amounts of clotting factors, and the dose of  mL/kg requires a large volume infusion that many patients cannot tolerate. Fresh frozen plasma can be available for rapid administration as universal donor (AB+) without the need for type and cross­match. One common clinical issue has centered on the advisability of platelet transfusion after spontaneous primary intracerebral hemorrhage in patients who are taking antiplatelet therapy. A multicenter, randomized controlled trial found that administering platelets to this subset of patients who sustained a spontaneous intracerebral hemorrhage resulted in higher rates of mortality and serious adverse events compared to a group who received standard care. As a
 result, perform standard care without platelet transfusion for patients who are taking antiplatelet therapy.
TABLE 166­5
Reversal of Anticoagulation for Intracerebral Hemorrhage
Anticoagulant Reversal Agent Comment
Warfarin Vitamin K 5–10 milligrams IV Onset of action of IV vitamin K is  h, with maximal effect at 6–24 h. PCC and IV vitamin K act synergistically in INR reduction.
Fresh frozen plasma  units IV Full dose  mL/kg limited by volume.
Prothrombin complex concentrate (PCC)  IU/kg IV Dose­related risk of thromboembolism; available as 3­factor (II, IX, X) and 4­factor (II, VII, IX, X) PCC; use what is available in your institution.
Onset of action of PCC is about  min with a half­life of 4–6 h.
Aspirin and Obtain consultation if available when considering platelet CAUTION: Platelet reversal may cause coronary or arterial adenosine infusion thrombosis and worsen outcome.
diphosphate receptor agonists
Unfractionated  milligram protamine/100 units of UFH; maximum dose, Infusion rate ≤5 milligrams/min; risk of hypersensitivity in patients with heparin (UFH)  milligrams; calculate last  h of heparin dose to fish allergy or prior protamine exposure: premedicate with determine protamine dose because heparin has short half­ hydrocortisone 500 milligrams IV and diphenhydramine  milligrams life IV.
Low­molecular­ If last dose within  h, give  milligram protamine/1 See above protamine cautions. Infusion rate ≤5 milligrams/min; higher weight heparin milligram LMWH; maximum dose,  milligrams infusion rates can cause hypotension or bradycardia.
(LMWH)
If last dose 8–12 h ago, give .5 milligram protamine/1 milligram LMWH
If last dose ≥12 h ago, do not give protamine
Direct thrombin
Idarucizumab
 grams IV to reverse dabigatran62 inhibitor or factor Xa inhibitors

Recombinant factor VIIa does not improve survival or functional outcome after intracerebral hemorrhage. Prothrombin complex concentrates are effective and rapidly reverse oral anticoagulants; however, morbidity and mortality remain high even when the coagulopathy is
 reversed. Manage intracerebral hemorrhage related to fibrinolytic therapy with standard intracerebral hemorrhage treatment along with platelet
 and cryoprecipitate infusions, although little evidence exists to guide therapy in these cases.


