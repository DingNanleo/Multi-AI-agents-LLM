## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 157: Tetanus
Alan X. You; Donna L. Carden; Joel Moll
INTRODUCTION AND EPIDEMIOLOGY
,2
Tetanus is uncommon in the United States, but worldwide estimates are approximately 100,000 cases per year, with a mortality rate of 35% to 40%.
The Centers for Disease Control and Prevention defines tetanus as a syndrome of acute onset of hypertonia and/or painful muscular contractions

(usually of the muscles of the jaw and neck) and generalized muscle spasms without other apparent medical cause. In the United States, tetanus is a reportable disease, aggregated through the National Notifiable Diseases Surveillance System.
Improved childbirth practices, widespread immunization programs for children, decennial tetanus boosters for adults, mechanization of agriculture, and use of chemical fertilizers rather than animal manure have all resulted in a >95% decline in the annual incidence of tetanus in the United States
  since 1947. From 2009 to 2015, 197 tetanus cases were reported in the United States, with  deaths. Most patients who develop tetanus have inadequate immunity to the disease. Due to waning immunity and failure to receive routine boosters, only 31% of Americans >70 years old have
 adequate tetanus immunity. Tetanus among children and neonatal tetanus are uncommon. The case fatality rate is approximately 8%, and patients
,4
>55 years of age account for all deaths.
Most cases of tetanus in the United States are associated with an acute wound. Puncture, contaminated, infected, or devitalized wounds account for approximately 70% of tetanus cases. Although less common, chronic wounds and dental abscesses are also associated with the disease. Diabetics and
,6 injection drug users have an increased risk of contracting tetanus.
Two thirds of patients who develop tetanus do not seek medical care for their initial wound. Of those who do seek initial treatment and later develop
 tetanus, up to 95% do not receive appropriate therapy.
PATHOPHYSIOLOGY
Clostridium tetani is a motile, nonencapsulated, anaerobic gram­positive rod; it produces toxins that cause tetanus. C. tetani exists in either a vegetative or spore­forming state. The spores are ubiquitous in soil and animal feces and can survive on environmental surfaces for years. In
,7 agricultural areas, adults may harbor the organism; spores are found in many places, including on skin or in contaminated heroin. C. tetani is usually introduced into a wound in the spore­forming, noninvasive state but can germinate into the toxin­producing, vegetative form if tissue oxygen tension is reduced. Crushed or devitalized tissue, a foreign body, or the development of infection favors the growth of the toxin­producing
,8 form of C. tetani.
C. tetani produces two exotoxins: tetanolysin, which facilitates growth of the bacterial population; and tetanospasmin, a powerful neurotoxin responsible for all of the clinical manifestations of tetanus. Tetanospasmin reaches the nervous system by hematogenous spread of the exotoxin to peripheral nerves and by retrograde intraneuronal transport. Tetanospasmin does not cross the blood–brain barrier, but retrograde intraneuronal
 transport of the exotoxin enables tetanospasmin to gain access to the CNS.
Tetanospasmin prevents the release of the inhibitory neurotransmitters glycine and γ­aminobutyric acid from presynaptic nerve terminals, releasing the nervous system from its normal inhibitory control. Loss of inhibition may also affect the preganglionic sympathetic neurons, resulting in
7­10 sympathetic overactivity and high circulating catecholamine levels.
CLINICAL FEATURES

Tetanus results in generalized muscular rigidity, violent muscular contractions, and autonomic nervous system instability. Wounds that become
Chapter 157: Tetanus, Alan X. You; Donna L. Carden; Joel Moll c©o2n0t2a5m MincaGterda ww iHthi ltl.o Axilnl R­pirgohdtsu cRinegs eCr.v teedta. n iT aerrem osft oefn U psuen c * tPurriev awcoyu Pnodlsic, yb u * t N cootnictaem * iAnactceeds wsibouilintyds range from deep lacerations to minor abrasions. 
No wound exists in up to 10% of patients with tetanus. Tetanus can also develop after surgical procedures, otitis media, or abortion and can
,11 develop in injection drug users from contaminated heroin and in neonates through infection of the umbilical stump. The incubation period for tetanus ranges from <24 hours to >1 month. Short incubation periods are associated with severe disease and a poor prognosis. Clinical tetanus comes in three forms: generalized, cephalic, and local.
Generalized tetanus accounts for about 80% of cases. The most frequent presenting complaints of patients with generalized tetanus are pain and stiffness in the masseter muscles (“lockjaw”). Nerves with short axons are first involved, with symptoms in the facial muscles; later, descending progression to the muscles of the neck, trunk, and extremities occurs. The transition from muscle stiffness to rigidity leads to the development of trismus and the characteristic facial expression called risus sardonicus (sardonic smile). Reflex convulsive spasms and tonic muscle contractions are responsible for the development of dysphagia, opisthotonic flexing of the arms, clenching of the fists, and extension of the lower extremities. Spasms
 can last for  to  weeks. Recovery depends on regrowth of axonal nerve terminals and may take months. Complications of tetanus include rhabdomyolysis and long­bone fractures secondary to violent muscle contractions. The mental status is normal, an important consideration in differentiating tetanus from other disorders (Table 157­1). Patients remain conscious and alert unless laryngospasm or contraction of respiratory
,8 muscles results in respiratory compromise. Aspiration pneumonia is present in 50% to 70% of autopsied cases.
TABLE 157­1
Differential Diagnosis of Tetanus
Disorder Comments
Strychnine poisoning See Chapter 201, “Pesticides.”
Dystonic reaction (phenothiazines, See Chapter 180, “Antipsychotics.” metoclopramide)
Hypocalcemic tetany See Chapter , “Fluids and Electrolytes.”
Malignant neuroleptic syndrome See Chapter 180, “Antipsychotics.”
Serotonin syndrome See Chapter 178, “Atypical and Serotonergic Antidepressants.”
Stiff person syndrome Centrally mediated motor hyperexcitability with persistent and intense spasms, particularly of the proximal lower limbs and lumbar paraspinal muscles.
Peritonsillar abscess See Chapter 246, “Neck and Upper Airway.”
Peritonitis See Chapter , “Acute Abdominal Pain.”
Meningeal irritation (bacterial meningitis, See Chapter 174, “Central Nervous System and Spinal Infections,” and Chapter 166, “Spontaneous subarachnoid hemorrhage) Subarachnoid and Intracerebral Hemorrhage.”
Rabies See Chapter 158, “Rabies.”
Temporomandibular joint disease See Chapter 243, “Face and Jaw Emergencies.”
Autonomic dysfunction and a hypersympathetic state including tachycardia, labile hypertension, profuse sweating, hyperpyrexia, and increased
8­10 urinary excretion of catecholamines occur during the second week of clinical generalized tetanus. Neonatal tetanus, a form of generalized
 tetanus, develops in infants born to inadequately immunized mothers, frequently after unsterile treatment of the umbilical cord stump. Infants with
 neonatal tetanus are weak, irritable, and have an inability to suck. Symptoms are evident by the second week of life.
Cephalic tetanus follows injuries to the head or occasionally otitis media and results in dysfunction of the cranial nerves, most commonly the seventh. It has a poor prognosis.
Local tetanus displays muscle rigidity in proximity to the site of injury and usually resolves completely after weeks to months. Local tetanus may
,8 progress to the generalized form of the disease. Approximately 1% of these cases are fatal.
DIAGNOSIS

Tetanus is a clinical diagnosis. In the United States, 96% of tetanus cases occur in those with unknown or inadequate immunization history. The
,13 elderly, those on hemodialysis, and the immunocompromised often have inadequate immunity. There are no laboratory tests to diagnose tetanus, although serum antitoxin titers of >0.01 IU/mL are usually protective. An immunochromatographic dipstick test allows rapid assessment of immunity,
 with an 88% sensitivity and 98% specificity; it may be useful in regions with high disease incidence. However, tetanus can occur in patients with
 protective levels of antitetanus antibodies. Wound culture is of limited value because C. tetani may be cultured from wounds in the absence of clinical disease and may not be recovered in patients with documented tetanus.
Table 157­1 provides the differential diagnosis of tetanus. Strychnine poisoning most closely mimics the clinical picture of generalized tetanus.
TREATMENT
Treatment is supportive (Table 157­2). Identify and debride the wound to improve the oxidation­reduction potential of infected tissue, remove spores, and prevent further toxin production. Provide tetanus immunization because the disease does not result in immunity.
TABLE 157­2
Treatment of Tetanus
Respiratory management Sedation and neuromuscular blockade with succinylcholine or vecuronium for intubation and ongoing mechanical ventilation
Immunotherapy Tetanus immunoglobulin, 3000–6000 units IM opposite side of the body from tetanus toxoid, with at least a portion around the wound site and
Tetanus toxoid (DTaP or Td/Tdap depending on age), .5 mL IM at presentation, and  wk and  mo after presentation
Wound care Wound debridement
Antibiotic therapy Metronidazole, 500 milligrams IV every  h. Penicillin can theoretically potentiate the effects of tetanospasm.
Muscle relaxation Diazepam preferred
Management of autonomic Magnesium sulfate,  milligrams/kg IV loading, then  grams/h (1.5 grams/h if ≤45 kg) continuous infusion to maintain dysfunction blood level of .0–4.0 mmol/L or
Labetalol, .25–1.0 milligram/min continuous IV infusion
Morphine sulfate, .5–1.0 milligram/kg/h
Clonidine, 300 micrograms every  h by nasogastric tube
Abbreviations: DTaP = diphtheria and tetanus toxoids and acellular pertussis vaccine; Tdap = tetanus toxoid with lower doses of diphtheria and acellular pertussis than DTaP; Td = tetanus­diphtheria.
Admit patients with tetanus to the intensive care unit. Respiratory compromise requires immediate neuromuscular blockade and intubation. Minimize environmental stimuli to prevent the precipitation of reflex convulsive spasms.
TETANUS IMMUNOGLOBULIN
Human tetanus immunoglobulin neutralizes circulating tetanospasmin and toxin in the wound but not toxin already fixed in the
 nervous system. Even though tetanus immunoglobulin does not reduce clinical symptoms of tetanus, it may reduce mortality. For postexposure prophylaxis, a single dose of 250 units (4 units/kg in children) IM given in the anterolateral thigh or deltoid is recommended. For the treatment of clinical tetanus, the optimal dose of tetanus immunoglobulin is unknown, but 3000 to 6000 units IM is the usual recommended dose, administered in a
 separate syringe and opposite the site of tetanus toxoid administration. A portion of the dose is optimally given in and around the wound. Intrathecal
 administration of tetanus immunoglobulin does not appear to have advantages over standard IM delivery. Give tetanus immunoglobulin before wound debridement because exotoxin may be released during wound manipulation. Repeated doses of tetanus immunoglobulin are unnecessary because the half­life is  days.
ANTIBIOTICS
18­20
Antibiotics have limited utility; when used, metronidazole, 500 milligrams IV every  to  hours, is the antibiotic regimen of choice. Penicillin can
 theoretically potentiate the effects of tetanospasmin, but no clinical data show an adverse effect in use.
MUSCLE RELAXANTS
Tetanospasmin prevents neurotransmitter release at inhibitory interneurons, so tetanus therapy aims at restoring normal inhibition. The benzodiazepines are centrally acting inhibitory agents used for this purpose. Diazepam is the preferred benzodiazepine for treatment of tetanus because of cost and availability. Another option is midazolam, a water­soluble agent, administered as a continuous infusion in cases
 that require large doses of benzodiazepines. Intrathecal baclofen has some effect in the treatment of tetanus but is not recommended as
,21 routine therapy.
NEUROMUSCULAR BLOCKADE
Prolonged neuromuscular blockade aids in control of ventilation, muscular spasms, secondary fractures, and rhabdomyolysis. Succinylcholine can be given early for emergency airway control, whereas vecuronium is a good option for prolonged blockade because of minimal cardiovascular side
 effects.
TREATMENT OF AUTONOMIC DYSFUNCTION
One randomized controlled trial in 256 patients with severe tetanus demonstrated that magnesium sulfate reduced autonomic instability and muscle
  spasm in the disease. Magnesium sulfate also reduces urinary catecholamine excretion in patients with severe tetanus. However, a meta­analysis failed to show a benefit of magnesium sulfate on tetanus mortality, and the effect of the drug on duration of intensive care unit and hospital stay and
 need for ventilatory support was unclear.
Adrenergic blocking agents may reduce the autonomic dysfunction of severe tetanus. A short­acting β­blocker such as esmolol, or a combined α­ and
β­adrenergic blocking agent such as labetalol, are options.
Morphine sulfate reduces sympathetic α­adrenergic tone and central sympathetic efferent discharge and produces peripheral arteriolar and venous
 dilatation. Clonidine, a central α ­receptor agonist, may reduce the sympathetic hyperactivity that causes autonomic dysfunction and thereby provide

 better control of crises.
TETANUS IMMUNIZATION
Patients who recover from tetanus must receive active immunization, because infection does not confer immunity and vaccination is the only means of disease prevention. Give adsorbed tetanus toxoid (0.5 mL) IM at the time of presentation and at  weeks and  months after injury.
In patients with incomplete vaccinations, with tetanus­prone wounds and more than  years from previous vaccination, or with any wounds more than
 years from vaccination, use tetanus­diphtheria if ≥7 years old.  Use diphtheria and tetanus toxoids and acellular pertussis vaccine (DTaP) for
 patients <7 years of age. Because of the recent increase in the incidence of pertussis, adults should receive a single lifetime dose of Tdap (tetanus
 toxoid with lower doses of diphtheria and acellular pertussis than DTaP) to replace one tetanus­diphtheria booster. Adolescents should also receive
 a single dose of Tdap, preferably at  to  years of age. An inadvertent dose of DTaP in an adult would count as the single lifetime dose of Tdap.
The revised Advisory Committee on Immunization Practices guidelines recommend administering a dose of Tdap during each pregnancy, irrespective of the patient’s prior history of receiving Tdap or interval since last injection, to maximize the maternal antibody response and passive antibody levels
 in the newborn. Tdap may be given at any point during pregnancy, with optimal timing between  and  weeks of gestation unless treating a specific wound. For women who have never received Tdap, it should be given to the mother immediately postpartum.

Table 157­3 summarizes the guidelines for tetanus immunization and tetanus prophylaxis in wound management. Patients with human immunodeficiency virus infection or severe immunodeficiency who have contaminated wounds should also receive tetanus immunoglobulin,
 regardless of their tetanus immunization history. Only about 60% of patients with an acute injury who seek medical care receive
 appropriate tetanus wound prophylaxis. Table 157­2 summarizes the management of tetanus.
TABLE 157­3
Summary Guide to Tetanus Prophylaxis in Wound Management
Clean, Minor Wounds All Other Wounds* History of Adsorbed Tetanus Toxoid (doses) Tdap or Td† IM TIG, 250 units IM Tdap or Td† TIG, 250 units IM
Unknown or less than  Yes‡ No Yes Yes
 or more§ No¶ No Yes# No
Abbreviations: DTaP = diphtheria and tetanus toxoids and acellular pertussis vaccine; DT = diphtheria­tetanus toxoids; Td = tetanus­diphtheria; Tdap = tetanus toxoid with lower doses of diphtheria and acellular pertussis than DTaP; TIG = tetanus immunoglobulin.
*For example, wounds >6 hours old, contaminated with soil, saliva, feces, or dirt; puncture or crush wounds; avulsions; wounds from missiles, burns, or frostbite.
†DTaP for children <7 years of age (DT if pertussis vaccine is contraindicated); Td for persons ≥7 years of age. A single booster dose of Tdap is recommended for adolescents and adults to replace  Td booster.
‡
The primary immunization series should be completed. Three doses total are required, with the second dose given at least  weeks after the first dose and the third dose given  months later.
§If only three doses of fluid toxoid have been received, then a fourth dose of absorbed toxoid should be given.
¶Yes, if >10 years since last dose.
#Yes, if >5 years since last dose. Boosters more frequent than every  years may predispose to side effects.
Adverse reactions following tetanus immunization include erythema, induration, and pain at the injection site. Local reactions are common and usually self­limited. Exaggerated local reactions (Arthus reactions) occur occasionally and involve extensive pain and swelling of the entire extremity.
Arthus reactions occur most often in adults with high serum tetanus antitoxin levels who have received frequent doses of tetanus toxoid, which is the reason this therapy is limited to 10­year intervals.
Contraindications to tetanus­diphtheria or Tdap include a history of serious allergic reaction (respiratory compromise or cardiovascular collapse) to vaccine components. History of encephalopathy (e.g., coma or prolonged seizures) not attributable to an identifiable cause within  days of administration of a pertussis vaccine is a contraindication to Tdap. Reasons to defer tetanus­diphtheria or Tdap include Guillain­Barré syndrome ≤6 weeks after a previous dose of tetanus toxoid­containing vaccine, moderate to severe acute illness, unstable neurologic condition, or history of an

Arthus reaction to a tetanus toxoid–containing vaccine administered <10 years previously. If tetanus toxoid is contraindicated, consider passive immunization with tetanus immunoglobulin.


