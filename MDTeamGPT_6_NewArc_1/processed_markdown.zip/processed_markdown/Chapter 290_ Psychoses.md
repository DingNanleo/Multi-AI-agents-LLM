## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 290: Psychoses
Adam Z. Tobias
INTRODUCTION AND EPIDEMIOLOGY

Psychosis has been defined as a “fundamental derangement of the mind characterized by defective or lost contact with reality.” The Diagnostic and

Statistical Manual of Mental Disorders, Fifth Edition, defines psychotic disorders as those that include abnormalities in one or more of five domains: hallucinations, delusions, disorganized or abnormal motor behavior, disorganized thinking, and negative symptoms. The hallmark of these
  psychoses, schizophrenia, has a worldwide prevalence of .5% to 1% and affects approximately .4 million adults in the United States. Schizophrenia
5­7 is considered one of the leading causes of chronic incapacity.
The assessment of the psychotic patient presenting to the ED can be challenging, because patients may be agitated, combative, uncooperative, or unable to provide any history. The goals of evaluation are multiple. First, minimize any potential harm to the patient and ensure the safety of the ED staff and other patients. In the case of an aggressive or violent patient, this may require the use of verbal de­escalation techniques, physical restraints, or chemical sedation. Second, assess for any coexisting or confounding medical or traumatic conditions. Emergency care providers are gatekeepers to the psychiatric world, because once the patient is funneled into the psychiatric treatment realm, organic conditions may become more difficult to
 identify and treat. Psychiatric conditions contribute to increased mortality from comorbid medical conditions as compared to the general population.

In fact, patients with schizophrenia have a life expectancy of approximately  years less than that of the general population. Finally, aim to optimize the treatment of the patient’s underlying psychiatric illness, either by connection with the appropriate inpatient or outpatient resources or by contacting their psychiatrist.
PATHOPHYSIOLOGY
,11
Both environmental and genetic factors contribute to the schizophrenia spectrum of disorders. The disorders have been linked to a spectrum of risk alleles, with overlap between the alleles associated with schizophrenia and those associated with other disorders such as autism and bipolar
 disorder. It is thought that dopamine acts as the common final pathway of a wide variety of predisposing factors, either environmental, genetic, or both, that lead to the disease. Other neurotransmitters, such as glutamate and adenosine, may also collaborate with dopamine to give rise to the entire
,14 picture of schizophrenia.
CLINICAL FEATURES
HISTORY
Features of psychoses include hallucinations, delusions, disorganized thinking, and negative symptoms.

A hallucination is an “apparent, often strong subjective perception of an external object or event when no such stimulus or situation is present.”
Although hallucinations may occur in any sensory modality, they are most commonly auditory in schizophrenia and other psychotic disorders.
Typically these are experienced as voices distinct from the individual’s own thoughts. Not all hallucinations are considered to be pathologic; they may be a normal part of certain religious and cultural experiences.

A delusion is “a false belief or wrong judgment, sometimes associated with hallucinations, held with conviction despite evidence to the contrary.”
Delusions may be classified based on various themes, including grandiose (i.e., “when an individual believes that he or she has exceptional abilities, wealth, or fame”), persecutory, erotomanic (i.e., “when an individual believes falsely that another person is in love with him or her”), and referential or ideas of reference (i.e., “belief that certain gestures, comments, environmental cues, and so forth are directed at oneself”). Delusions are considered

 bCihzaarprtee irf 2th9e0y: Parsey cclheoasrleys i,m Apdlaamus iZb.l eT. oInb itahse ED, a nonbizarre delusion may be difficult to distinguish from a strongly held idea. 
. Terms of Use * Privacy Policy * Notice * Accessibility
Typically, disorganized thinking is inferred from a patient’s speech. Commonly encountered patterns may include derailment or loose associations, wherein the individual switches from one topic to another; tangentiality, wherein answers to questions may be unrelated or loosely related; and word
 salad, wherein the individual’s speech becomes so disorganized that it becomes nearly incomprehensible.
Negative symptoms associated with psychotic disorders include avolition (decreased motivation), diminished emotional expression, anhedonia
(decreased ability to experience pleasure), asociality (decreased interest in social interaction), and alogia (decreased speech). Patients with negative symptoms often present with flat affect. These symptoms can be the most chronically impairing features of psychoses.
PHYSICAL EXAMINATION
Aside from grossly disorganized or abnormal motor behavior (discussed below), there are no specific physical findings associated with the psychotic disorders. The goal of physical examination is the exclusion of coexisting medical or traumatic conditions. For agitated patients, be particularly vigilant to assess for any self­inflicted injuries, environmental injuries such as frostbite, or injuries occurring as a result of combative behavior or the restraint process.
Grossly disorganized or abnormal motor behavior may take on various forms, although it is likely most familiar to emergency practitioners as unpredictable agitation. Catatonia is a “marked decrease in reactivity to the environment.” Catatonic features may range from negativism, which is a resistance to instructions, to maintenance of a rigid or inappropriate posture, to complete lack of motor or verbal response. Catatonic behavior may
 occur in association with a variety of psychiatric and medical conditions.
DIAGNOSIS AND DIFFERENTIAL DIAGNOSIS
Psychotic symptoms may be caused by numerous medical conditions and often occur in conjunction with delirium. Consider medical causes before attributing psychosis to a primary psychiatric illness. Some of the many potential causes include infections such as encephalitis, meningitis, or sepsis;

CNS conditions such as stroke, seizure, Parkinson’s disease, or brain tumor; and metabolic derangements such as hypoglycemia or hepatic
17­20 encephalopathy. Additionally, various medications and illicit substances may give rise to psychotic symptoms (Table 290­1).
TABLE 290­1
Common Medications and Drugs of Abuse Causing Psychosis
Medications Drugs of Abuse
Corticosteroids Ethanol* Fluoroquinolones Cocaine
Atropine and other anticholinergics Amphetamines and other stimulants (including “bath salts”)
Dextromethorphan LSD and other hallucinogens
Benzodiazepines* Marijuana
Phencyclidine (PCP)
MDMA (ecstasy)
* Psychosis is more commonly seen in benzodiazepine withdrawal but can occur with ethanol intoxication or withdrawal.
The Diagnostic and Statistical Manual of Mental Disorders, Fifth Edition, delineates specific diagnostic criteria for the schizophrenia spectrum and other psychotic disorders (see discussion below). However, such granular distinctions are typically not necessary or relevant for emergency assessment and treatment. Rather than making a specific psychiatric diagnosis, the ED provider’s focus should be on emergency treatment and stabilization, identification of comorbid conditions, and appropriate disposition. Diagnostic testing is directed by the history and physical examination. Routine extensive laboratory testing for otherwise stable, cooperative, and previously diagnosed psychiatric patients is of low yield and
 need not be performed in most cases. Similarly, urine toxicologic screening rarely affects ED management and need not be routinely obtained.
Many psychotic patients presenting to the ED have been previously diagnosed with a psychiatric condition. In such cases, determine whether there has been an acute change from the patient’s baseline and whether the current presentation is confounded by another condition that requires medical treatment. In cases where the patient is unable to aid with providing history, use other resources, including past medical records, medication lists, family members, and case workers.

For patients with new­onset psychosis, the ED is a common point of first contact with the healthcare system. The provider must then determine whether the patient’s psychosis is the by­product of an acute medical condition, a reaction to a medication or illicit substance, or truly the new onset of a primary psychiatric illness. Newly symptomatic patients often warrant a more extensive medical evaluation than those with known underlying psychotic disorders.
DISPOSITION AND FOLLOW­UP
Patients with a chronic psychotic illness may present anywhere along a spectrum ranging from high functioning to completely disabled. Guide disposition decisions by considerations of patient safety and optimization of treatment. Patients thought to be violent, at risk of self­harm, or unable to care for themselves typically require emergent psychiatric evaluation and possibly inpatient psychiatric care. Patients with new­onset psychosis (not thought to be due to a medical cause) or those with worsening of underlying psychotic symptoms should have psychiatric consultation in the ED, if available, or be transferred to a psychiatric facility. Patients with known psychoses under apparent good control may be referred for outpatient management. Ideally, such referrals should be made in consultation with the patient’s treating psychiatric provider.
Finally, patients with psychosis secondary to a medical condition or those with comorbid illness should be managed accordingly. Give special consideration to a patient’s functional level and ability to manage the medical condition as an outpatient. For example, a schizophrenic patient with an infection that might otherwise be treated with oral antibiotics at home might benefit from hospitalization if there is doubt about the patient’s ability to comply with treatment and follow­up instructions.
PHARMACOTHERAPY
Antipsychotic (neuroleptic) medications are typically used in the treatment of schizophrenia and the other psychoses. The exact mechanism of action of the antipsychotics is not known. The majority of antipsychotics block the D dopamine receptors and 5­HT serotonin receptors in the brain to a
 2A varying degree. Antipsychotics are classified as first­generation (typical) or second­generation (atypical) antipsychotics.
The typical antipsychotic medications are often categorized as being of low, medium, or high potency. The “potency” of these drugs does not refer to effectiveness, but rather to the degree of dopamine blockade. High­potency drugs have higher D dopamine receptor blockade and lower serotonergic
 and muscarinic binding affinity. In general, low­potency medications tend to be more sedating and are more often associated with hypotension, dizziness, and anticholinergic symptoms. High­potency medications are generally less sedating, but are more frequently associated with
 extrapyramidal effects such as tremors, rigidity, muscle spasms, and akathisia. Table 290­2 reviews the common typical antipsychotics.
TABLE 290­2
Typical Antipsychotics
Generic Name Brand Name Relative Potency U.S. Food and Drug Administration Warnings
Phenothiazines
Chlorpromazine Thorazine® Low
Mesoridazine Serentil® Intermediate QT prolongation c
Thioridazine Mellaril® Intermediate QT prolongation c
Perphenazine Trilafon® Intermediate
Trifluoperazine Stelazine® High
Fluphenazine Prolixin® High
Thioxanthenes
Loxapine Loxitane® Intermediate
Thiothixene Navane® High
Dihydroindolones
Molindone Moban® Intermediate
Butyrophenones
Haloperidol Haldol® High QT prolongation and torsades de pointes c
Droperidol Inapsine® High QT prolongation and torsades de pointes c
The U.S. Food and Drug Administration (FDA) has placed black box warnings on a number of the typical antipsychotics, due to concerns about possible cardiac dysrhythmias associated with their use. In particular, several of these medications have been associated with QT prolongation and the FDA c recommends evaluation of the QT interval prior to their use. In clinical situations in which rapid treatment of agitation is necessary, a priori c determination of the QT interval is impractical and usually impossible. If ECG data are available from the ED visit, these should be reviewed for c evidence of QT prolongation. Similarly, if prior ECG data are available, incorporate them into clinical decision making. Haloperidol remains a popular c
,24 and effective agent for rapid tranquilization, although newer agents such as olanzapine may be safer and equally effective. Unfortunately, QT c prolongation does not directly correlate with the clinical risk of dysrhythmias or the development of the malignant arrhythmia torsades de pointes.
The black box warnings have led to apprehension in the use of highly effective medications.
The atypical antipsychotics (Table 290­3) are generally newer medications that more specifically target the dopamine receptors or inhibit the reuptake of serotonin. Early studies showed that they had increased efficacy in the treatment of the negative symptoms of psychosis, although more
 recent data have found this effect to be comparable to that of the typical antipsychotics. Based on this improved receptor specificity, adverse effects such as sedation, extrapyramidal effects, QT prolongation, and tardive dyskinesia are generally reduced but are not completely eliminated. The c incidence of hypotension does not appear to have been significantly altered. The FDA has placed a black box warning on both typical and atypical psychotics for their off­label use in managing agitation and psychosis in elderly patients with dementia, due to increased rates of cerebrovascular
,27 accidents, cardiovascular events, and mortality associated with chronic use.
TABLE 290­3
Atypical Antipsychotics
U.S. Food and Drug Administration–
Drug Warnings and Common Side Effects (BLACK BOX WARNINGS IN CAPS)
Approved Indications
Clozapine Treatment­resistant schizophrenia Sedation, dizziness, hypotension, tachycardia, salivation, weight gain, hyperthermia.
(Clozaril®) Reduction in the risk of recurrent suicidal behavior in schizophrenic or AGRANULOCYTOSIS, SEIZURES, MYOCARDITIS, OTHER ADVERSE CARDIOVASCULAR AND schizoaffective disorders RESPIRATORY EFFECTS
Olanzapine Schizophrenia CVAE, sedation, postural hypotension, hyperglycemia, weight gain, dizziness
(Zyprexa®) Bipolar disorder
Agitation associated with schizophrenia and bipolar I mania
Quetiapine Bipolar mania NMS, hyperglycemia, sedation, hypotension, headache, weight gain
(Seroquel®) Schizophrenia
CATARACT FORMATION
Risperidone Schizophrenia Extrapyramidal effects, hyperglycemia, hypotension, hyperprolactinemia, weight gain
(Risperdal®) Bipolar mania
Ziprasidone Schizophrenia Sedation, rash, dizziness, hypotension, hyperglycemia, extrapyramidal effects
(Geodon®) Bipolar mania
Acute agitation in schizophrenic patients QT PROLONGATION AND RISK OF SUDDEN DEATH
Aripiprazole Schizophrenia NMS, CVAE, hyperglycemia, seizure, hypotension, headache, akathisia
(Abilify®) Bipolar disorder
Asenapine Schizophrenia Blood dyscrasias, cerebrovascular effects, dyslipidemia, extrapyramidal symptoms, NMS,
(Saphris, Bipolar mania hyperglycemia, QT prolongation, orthostatic hypotension, increased mortality with chronic c
Sycrest®) use in dementia patients
Iloperidone Schizophrenia
(Fanapt®)
Paliperidone Schizophrenia
(Invega, Schizoaffective disorder
Sustenna®)
Abbreviations: CVAE = cerebrovascular adverse event; NMS = neuroleptic malignant syndrome.
ADVERSE EFFECTS
The following side effects are more commonly associated with the typical antipsychotics, but may also occur with medications in the atypical class: acute dystonia, akathisia, parkinsonism, anticholinergic effects, cardiovascular effects, and neuroleptic malignant syndrome.
Acute Dystonia
Acute dystonias are probably the most common side effect of antipsychotic medications seen in the ED and are more common in younger patients and
 those who have never taken antipsychotic drugs before. Muscle spasms of the neck, face, and back are the most common dystonias, but oculogyric crisis and even laryngospasm may also occur. Treatment with either benztropine,  to  milligrams IV or IM, or diphenhydramine,  to  milligrams IV, rapidly corrects the dystonia. For persistent reactions, both medications may be used, and benzodiazepines may be added for treatment failures or given prophylactically. Dystonias often recur despite dosage reduction or discontinuation of the offending antipsychotic.
Akathisia (Motor Restlessness)
Akathisia, a sensation of motor restlessness with a subjective desire to move, can begin several days to several weeks after initiation of antipsychotic treatment. Management can be difficult. If possible, decrease the dosage of the antipsychotic after psychiatric consultation. The best treatment is probably administration of benzodiazepines or β­blockers such as propranolol.
Antiparkinsonian or anticholinergic drugs such as benztropine,  milligram PO twice daily, may also afford some relief, although these may lead to anticholinergic side effects if not subsequently tapered off. In refractory cases, the antipsychotic may need to be changed to an atypical agent.
Antipsychotic­Induced Parkinson’s Syndrome
A complete Parkinson’s syndrome, including bradykinesia, resting tremor, cogwheel rigidity, shuffling gait, masked facies, and drooling, can occur.

The elderly are at greatest risk, with development in the first month after initiation of the antipsychotic agent. Often only one or two features of the syndrome are obvious. Antipsychotic dosage reduction and/or anticholinergic medication is usually effective.
Anticholinergic Effects
Anticholinergic effects range from mild sedation to delirium. Peripheral manifestations may include dry mouth and skin, blurred vision, urinary retention, constipation, paralytic ileus, cardiac dysrhythmias, and exacerbation of angle­closure glaucoma. The central anticholinergic syndrome is characterized by dilated pupils, dysarthria, and an agitated delirium. Treatment is discontinuation of the antipsychotic and supportive measures.
Cardiovascular Effects
Cardiovascular side effects, such as orthostatic hypotension and tachycardia, are commonly encountered. These effects are likely related to anticholinergic and adrenergic blockade and occur at therapeutic dosages. Typically, hypotension can be managed with IV fluids. In severe cases, vasopressor support may be required. Additional effects caused by blockade of sodium, calcium, and potassium channels in the central nervous and cardiac systems are less well delineated. However, effects on specific potassium channels in the myocardium have been linked to the drug­induced
,29 prolongation of the QT interval associated with several of the antipsychotics. It is this mechanism of action by which the antipsychotics are c believed to induce torsades de pointes.
Neuroleptic Malignant Syndrome
Neuroleptic malignant syndrome is an uncommon idiosyncratic reaction to neuroleptic drugs manifested by rigidity, fever, autonomic instability
(tachycardia, diaphoresis, and blood pressure abnormalities), and a confusional state. Although high­potency antipsychotics may be more likely to cause the disorder, all antipsychotics are potential offenders. Neuroleptic malignant syndrome is a medical emergency and has a mortality rate as high as 20%. Management includes immediate discontinuation of the antipsychotic medication, hydration, and supportive treatment in an intensive care setting. Anticholinergic medications are not helpful and may worsen the condition by further impairing centrally mediated temperature regulation.
Medications such as dantrolene sodium or bromocriptine are sometimes used to relieve the rigidity.
SCHIZOPHRENIA SPECTRUM OF DISORDERS
The schizophrenia spectrum of disorders is listed in Table 290­4. Some of the more commonly encountered conditions are discussed in detail below.
TABLE 290­4
The Schizophrenia Spectrum of Disorders
Schizophrenia
Brief psychotic disorder
Substance/medication­induced psychotic disorder
Schizotypal personality disorder
Unspecified catatonia
Unspecified schizophrenia spectrum and other psychotic disorder
Catatonia associated with another mental disorder
Delusional disorder
Schizoaffective disorder
Schizophreniform disorder
Psychotic disorder due to another medical condition
Catatonic disorder due to another medical condition
Other specified schizophrenia spectrum and other psychotic disorder
Schizophrenia is the most common form of psychosis. It typically involves a wide range of impairments in functioning and may affect all areas of a patient’s life, including occupational and social aspects. It usually begins to manifest between the late teens and the mid­30s. Its course is characterized by acute episodes and periods of partial or full remission. It is diagnosed more in men than in women, and the incidence varies significantly based on age, gender, socioeconomic, racial, and geographic factors, with a higher incidence among migrants, urban populations, and
30­32 ,34 ethnic minorities. Patients with schizophrenia have high rates of medical comorbidity and concomitant substance abuse.
Signs of the disturbance must be present for at least  months for a formal diagnosis, and symptoms cannot be attributable to another medical condition or the effects of a substance. Diagnostic criteria are listed in Table 290­5. TABLE 290­5
Diagnostic Criteria for Schizophrenia2
Criterion A* Other Selected Criteria
Hallucinations Disturbance present for at least  months
Disorganized speech Significant deficiencies in major areas of function (work, self­care, interpersonal relations)
Delusions Depression, bipolar disorder, schizoaffective disorder ruled out
Negative symptoms Not attributable to another medical condition or substance
Grossly disorganized or catatonic behavior
* Must have two or more criteria and at least one must be delusions or disorganized speech.

Delusional disorder is diagnosed in the absence of schizophrenia and involves the presence of one or more delusions for at least  month. The central theme of the somatic type, and a potential trigger for an ED visit, is a preoccupation with health and organ function. For example, individuals
 may be convinced that they have an infestation of insects on their skin or that a part of their body is not functioning.

Schizoaffective disorder is about one third as prevalent as schizophrenia. It is characterized by Criterion A of schizophrenia (see Table 290­5) occurring concurrently with a major mood episode (major depressive or manic). Patients with schizophrenia and schizoaffective disorder have a 5%
 lifetime risk of suicide, with higher risk in patients with depressive symptoms.
Catatonia may occur in the context of various conditions. Medical conditions associated with catatonia include encephalitis, head trauma, hepatic encephalopathy, and neoplasms. The acute presentation of catatonia often includes stupor, and therefore, patients often have their first clinical
 contact in the ED. It is therefore important to recognize that catatonia is frequently associated with an organic cause.


