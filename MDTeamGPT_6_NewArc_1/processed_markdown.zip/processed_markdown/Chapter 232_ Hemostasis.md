## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 232: Hemostasis
Stephen John Cico
THE BLEEDING PATIENT
Most bleeding seen in the ED is a result of trauma—local wounds, lacerations, or other structural lesions—and the majority of traumatic bleeding occurs in patients with normal hemostatic mechanisms. In these patients, specific assessment of hemostasis is unnecessary. However, some ED
1­3 patients have abnormal bleeding due to impaired hemostasis. Identifying these patients requires attention to the history and physical findings.
Generally speaking, when patients have spontaneous bleeding from multiple sites, bleeding from untraumatized sites, delayed bleeding several hours after trauma, and bleeding into deep tissues or joints, the possibility of a bleeding disorder should be considered.
Important historical data that aid in identifying a congenital bleeding disorder include the presence of unusual or abnormal bleeding in the patient and other family members and any occurrence of excessive bleeding after dental extractions, surgical procedures, or trauma. Many patients with abnormal bleeding have an acquired disorder, such as liver disease, renal disease, or drug use (particularly ethanol, aspirin, NSAIDs, antiplatelet drugs, oral anticoagulants, antibiotics, and other salicylate­containing products). Many supplements and herbal preparations, including garlic, ginseng, ginkgo biloba, ginger, and vitamin E, can also increase bleeding tendencies.
The site of bleeding may provide an indication of the hemostatic abnormality. Mucocutaneous bleeding, including petechiae, ecchymoses, epistaxis, GI or GU bleeding, or heavy menstrual bleeding, is characteristic of qualitative or quantitative platelet disorders. Purpura is often associated with thrombocytopenia and commonly indicates a systemic illness. Bleeding into joints and potential spaces, such as between fascial planes and into the retroperitoneum, and delayed bleeding are most commonly associated with coagulation factor deficiencies. Patients who demonstrate both mucocutaneous bleeding and bleeding in deep spaces may have disorders such as disseminated intravascular coagulation, in which both platelet abnormalities and coagulation factor abnormalities are present (see Chapter 233, “Acquired Bleeding Disorders,” Chapter 234, “Clotting Disorders,” and Chapter 235, “Hemophilias and von Willebrand’s Disease”).
,5
Common laboratory tests for hemostasis have their limitations. They are generally useful and reliable for identifying disorders of coagulation factor function and quantitative platelet availability. However, tests of qualitative platelet function show a significant biologic variation, so that
 standardization has been difficult to achieve. In addition, liver disease and renal failure—two conditions that increase the potential for abnormal
,7 hemorrhage—may not give consistent and measurable abnormal results on routine tests of hemostasis.
THE PATIENT WITH A THROMBUS
A patient with an intravascular thrombosis, such as a venous thromboembolism or pulmonary embolus (particularly if recurrent), suggests the
 potential for an underlying hypercoagulable state (see Chapter 234). Premature coronary artery disease and acute coronary syndrome in individuals as young as teenagers have also been linked to hypercoagulable conditions. However, many, if not most, occurrences of intravascular thrombosis are not due to exaggerated hemostasis but rather are due to local conditions, with blood vessel wall injuries, local inflammation, or vascular stasis provoking the thromboembolic event.
The susceptibility to hypercoagulation may be acquired or genetically transmitted. Common acquired hypercoagulable disorders include essential thrombocythemia, polycythemia vera, paroxysmal nocturnal hemoglobinuria, antiphospholipid syndrome, and cancer (often occult at the time of acute thrombosis). Inherited hypercoagulable disorders include factor V Leiden, prothrombin mutations, hyperhomocysteinemia, and deficiencies of protein C, protein S, and antithrombin. Patients with inherited hypercoagulable conditions tend to have venous thrombosis, whereas those with acquired disorders can have both arterial and venous clots.
Proteins C and S are vitamin K–dependent antihemostatic factors made in the liver, and deficiencies of these proteins are inherited in an autosomal
 manner. Protein C is activated by thrombin and functions with protein S to stop fibrin formation and to stimulate the process of fibrinolysis.
Chapter 232: Hemostasis, Stephen John Cico 
A©n2t0it2h5r oMmcbGinra isw a Hlsioll. a Anl la Rntigihhetsm Rosetsaetricv epdro. t eTine rtmhast o bfl oUcskes * a Pctriivvaatceyd Pcooalicgyu l * a tNioonti cfaec * t oArsc.c Eelsesviabtielidty homocysteine level is also a known risk factor for thromboembolism.
Laboratory tests for a hypercoagulable diathesis show wide biologic variation, and standardization among laboratories has been difficult to achieve.
8­10
The clinical utility of testing patients for suspected hypercoagulable conditions is dependent on the specific disorder.
NORMAL COAGULATION
The normal hemostatic system consists of a complex process that limits blood loss through the formation of a platelet plug (primary hemostasis) and
 the production of cross­linked fibrin (secondary hemostasis), which strengthens the platelet plug. These reactions are counterregulated by the fibrinolytic system, which limits the size of the fibrin clot that is formed and thereby prevents excessive clot formation. Congenital and acquired
 abnormalities occur in all these systems. The affected patient may have excessive hemorrhage, excessive thrombus formation, or both.
PRIMARY HEMOSTASIS
Primary hemostasis is the platelet interaction with exposed vascular subendothelial collagen that results in the formation of a platelet plug at the site of injury. Required components for this to occur are normal vascular subendothelium (collagen), functional platelets, normal von Willebrand factor
(connects the platelet to the endothelium via glycoprotein Ib), and normal fibrinogen (connects the platelets to each other via glycoprotein IIb/IIIa)

(Figure 232­1). Primary hemostasis begins within  seconds of injury, is short lived, and requires secondary hemostasis for clot stabilization.
FIGURE 232­1. Primary hemostasis. GpIb = glycoprotein Ib; GpIIb/IIIa = glycoprotein IIb/IIIa; plt = platelet; vWF = von Willebrand factor.
SECONDARY HEMOSTASIS
Secondary hemostasis consists of the tightly regulated reactions of the plasma coagulation proteins. The final product is cross­linked fibrin, which is insoluble and strengthens the platelet plug formed in primary hemostasis (Figure 232­2).
FIGURE 232­2. ++
Secondary hemostasis. Ca = calcium; fibrinogen is factor I; PL = phospholipid surface (often platelets); prothrombin is factor II; TF = tissue factor.
Secondary hemostasis is also known as the coagulation cascade. The inactivated coagulation proteins (factors) are identified by Roman numerals, and after activation, the activated factor is designated by a. There are two independent activation pathways. The contact system is known as the contact
,11 activation pathway or intrinsic pathway, and the tissue factor system is known as the tissue factor pathway or extrinsic pathway. The pathways merge at the point of activation of factor X. Medications such as rivaroxaban, apixaban, and edoxaban inhibit the activity of factor Xa. The combination of factor Xa, factor Va, phospholipid, and calcium (“thrombinase complex”) more efficiently catalyzes the conversion of prothrombin to thrombin than free factor Xa. In turn, thrombin catalyzes the conversion of fibrinogen to fibrin monomer. Medications such as bivalirudin or dabigatran are direct thrombin inhibitors. The common pathway describes the steps from factor X activation to cross­linked fibrin formation.
THE FIBRINOLYTIC SYSTEM
The fibrinolytic system regulates the hemostatic mechanism by limiting the size of the fibrin clots that are formed (Figure 232­3). Tissue plasminogen activator, released from endothelial cells, is the principal physiologic trigger for the fibrinolytic process, converting plasminogen, synthesized in the liver and adsorbed in the fibrin clot, to plasmin. Plasmin degrades fibrinogen and fibrin monomer into low­molecular­weight fragments known as fibrin degradation products and degrades cross­linked fibrin into D­dimers.
FIGURE 232­3. The fibrinolytic system. FDP = fibrin degradation product; tPA = tissue plasminogen activator.
Other physiologic inhibitors of hemostasis with clinical relevance include antithrombin and the protein C–protein S system. Antithrombin is a protein that forms complexes with all the serine protease coagulation factors (factors XIIa, XIa, Xa, and IXa and thrombin), thereby inhibiting their function.
Heparin potentiates this interaction, which is the basis for its use as an anticoagulant. Proteins C and S are vitamin K–dependent factors that are produced in the liver. Activated protein C binds to the cell surface–bound protein S, and this complex is capable of inactivating the two plasma cofactors factors Va and VIIIa and inhibiting their participation in the coagulation cascade. A single amino acid substitution in factor V, a condition named factor V Leiden, prevents activated protein C from binding and inhibiting the activity of factor Va. Thus, patients with this inherited condition have prolonged thrombogenic factor Va activity. Factor V Leiden deficiency or defects in antithrombin, protein C, and protein S produce a potentially
 hypercoagulable condition and predispose the patient to venous thromboses.
TESTS OF HEMOSTASIS
Before embarking on a sequence of hemostatic testing, evaluate the patient in three areas: (1) Is the bleeding abnormal? (2) Is there a current medical
1­3 condition associated with increased hemorrhage? (3) Is there a structural cause that explains the bleeding?
The basic laboratory tests obtained for a patient with a suspected abnormal bleeding disorder are a CBC and platelet count, prothrombin time, and activated partial thromboplastin time (Table 232­1). The results of these tests, coupled with clinical evaluation, should enable formulation of a
,13 differential diagnosis. Additional studies are ordered as indicated (Table 232­2). Obtain hematologic consultation if the differential diagnosis or the laboratory approach is unclear. In patients with perioperative bleeding, the basic laboratory tests for coagulation are of little help in assessment or
 management.
TABLE 232­1
Initial Tests of Hemostasis
Screening Reference
Component Measured Clinical Correlations
Tests Value
Primary Hemostasis
Platelet count 150– Number of platelets per mm3 Decreased platelet count (thrombocytopenia): bleeding usually not a
400,000/mm3 problem until platelet count is <50,000/mm3 (50 × 109/L); high risk of
(150–400 × spontaneous bleeding, including CNS bleeding, seen with count of
109/L) <10,000/mm3 (10 × 109/L); usually due to decreased production or increased destruction of platelets
Elevated platelet count (thrombocytosis): commonly a reaction to inflammation or malignancy, and occurs in polycythemia vera; can be associated with hemorrhage or thrombosis
Bleeding time Variable Interaction between platelets and the Prolonged BT caused by:
(BT) Typically .5– subendothelium Thrombocytopenia (platelet count <50,000/mm3 or  × 109/L)
### .0 min using a
Abnormal platelet function (von Willebrand’s disease, antiplatelet
BT template drugs, uremia, liver disease)
Secondary Hemostasis
Prothrombin PT: 11–13 s; Extrinsic system and common pathway— Prolonged PT most commonly caused by: time (PT) and depends on factors VII, X, V, prothrombin, and Warfarin (inhibits production of vitamin K–dependent factors II, VII, IX, international reagent fibrinogen and X) normalized INR: .0 INR = .7 corresponds to approximately Liver disease with decreased factor synthesis ratio (INR) 30% activity of coagulation factors as a Antibiotics that inhibit vitamin K–dependent factors (moxalactam, whole cefamandole, cefotaxime, cefoperazone)
Activated 22–34 s Intrinsic system and common pathway— Prolonged aPTT most commonly caused by: partial Depends on factors XII, XI, IX, VIII, X, V, prothrombin, Heparin therapy thromboplastin type of and fibrinogen Factor deficiencies (factor levels have to be <30% of normal to cause time (aPTT) thromboplastin prolongation) reagent used
“Activated” with kaolin
Fibrinogen Slightly Protein made in liver; converted to fibrin Low levels seen in disseminated intravascular coagulation level variable as part of normal coagulation cascade Elevated in inflammatory processes (acute­phase reactant) according to specific test
Typically 200–
400 milligrams/dL
(2–4 g/L)
Thrombin 10–12 s Conversion of fibrinogen to fibrin Prolonged TCT caused by: clotting time monomer Low fibrinogen level
(TCT) Abnormal fibrinogen molecule (liver disease)
Presence of heparin, fibrin degradation products, or a paraprotein
(multiple myeloma); these interfere with the conversion
Occasionally seen in hyperfibrinogenemia
“Mix” testing15 Variable Performed when results on one or more If the mixing corrects the screening test result: one or more factor of the above screening tests is deficiencies are present prolonged; the patient’s plasma
(“abnormal”) is mixed with “normal” If the mixing does not correct the screening test result: a circulating plasma and the screening test is inhibitor is present repeated
TABLE 232­2
Additional Hemostatic Tests
Test Reference Value Component Measured Clinical Correlations/Comments
Fibrin degradation product FDP: variable depending on FDP test: measures breakdown Levels are elevated in diffuse intravascular
(FDP) and D­dimer levels specific test, typically <2.5–10 products from fibrinogen and fibrin coagulation, venous thrombosis, micrograms/mL (2.5–10 monomer pulmonary embolus, and liver disease, and milligrams/L) during pregnancy
D­Dimer: variable depending on D­Dimer test: measures breakdown specific test, typically <250–500 products of cross­linked fibrin nanograms/mL (250–500 micrograms/L)
Factor level assays 60%–130% of reference value Measures the percent activity of a To identify specific deficiencies and direct
(0.60–1.30 units/mL) specified factor compared to normal therapeutic management
Protein C level Variable Level of protein C in the blood Vitamin K dependent
Typically 60%–150% of Increases with age reference value Values higher in males than females
Deficiency associated with thromboembolism in people <50 y of age
Protein S level Variable Level of protein S in the blood Vitamin K dependent
Typically 60%–150% of Increases with age reference value Values higher in males than females
Deficiency associated with thromboembolism in people <50 y of age
Factor V Leiden (FVL) Variable Screening test looks for activated FVL not inactivated by activated protein C protein C resistance, and Heterozygotes have 7× and homozygotes confirmatory test analyzes DNA have a 20× increased lifetime risk of venous sequence of factor V gene thrombosis
Mutation associated with
Screening assay uses activated thromboembolism in people <50 y of age partial thromboplastin time with and without added activated protein
C
Antithrombin level Variable depending on specific Measures level of antithrombin in Not vitamin K dependent; patients with test the blood deficiency require higher dosages of heparin
Typically 20–45 milligrams/dL for anticoagulation therapy
(200–450 milligrams/L) Deficiency associated with thromboembolism in people <50 y of age
Antiphospholipid antibodies IgG <23 GPL units/mL and IgM Tests for antibodies that bind to Lupus anticoagulant: elevated in systemic
<11 MPL units/mL phospholipids lupus erythematosus (SLE) and other
Lupus anticoagulant autoimmune diseases
Anticardiolipin antibody Anticardiolipin antibody: elevated in SLE, other autoimmune diseases, syphilis, and
Behçet’s syndrome
Increased risk of spontaneous abortions, fetal loss, and fetal growth retardation
Anti–factor Xa activity During LMWH therapeutic use: Inhibition of factor Xa activity Used to monitor LMWH therapy and
.5–1.1 IU/mL determine levels of rivaroxaban, apixaban,
During LMWH prophylactic use: and edoxaban using agent­specific
.2–0.5 IU/mL calibration.
May be elevated in renal dysfunction
Platelet function assay 88–183 s Tests for platelet adhesion and Affected by uremia, anemia,
Variable aggregation thrombocytopenia, antiplatelet medications, and von Willebrand’s disease
Initial test done with epinephrine. A prolonged test is repeated using ADP, and if normal (<122 s), indicates probable aspirin effect
Peripheral blood smear Qualitative and quantitative Estimates quantity and appearance Allows identification of clumped platelets, based on visualization of platelets, WBCs, and red blood abnormal cells interfering with coagulation cells (leukemia)
Operator dependent
Dilute Russell viper venom 23–27 s Venom directly activates factor X and Prolonged in the presence of time converts prothrombin to thrombin antiphospholipid antibodies when phospholipid and factor V are present
Inhibitor screens Variable Verifies the presence or absence of Specific inhibitors: directed against one antibodies directed against one or coagulation factor, most commonly against more of the coagulation factors factor VIII
Nonspecific inhibitors: directed against more than one coagulation factor; example is lupus­type anticoagulant
Des­γ­carboxyprothrombin or Variable Measures inactive under­ Increased in vitamin K–deficient states, such
PIVKA II (protein induced by carboxylated form of prothrombin as hemorrhagic disease of the newborn vitamin K absence or antagonism) test Increased in overdoses of warfarin or cholestatic liver diseases that can respond to vitamin K therapy
Abbreviations: ADP = adenosine diphosphate; GPL =  microgram of affinity­purified immunoglobulin G anticardiolipin antibody from an original index serum; IgM = immunoglobulin M; MPL =  microgram of affinity­purified immunoglobulin M anticardiolipin antibody from an original index serum; LMWH = low­molecular­weight heparin.


