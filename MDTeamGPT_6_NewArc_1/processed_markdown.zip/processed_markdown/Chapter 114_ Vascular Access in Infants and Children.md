## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 114: Vascular Access in Infants and Children
Matthew L. Hansen
INTRODUCTION
This chapter presents the indications, advantages, and procedures for vascular access techniques in children: IO, central venous, US­guided peripheral venous, and umbilical venous access in the newborn.
INTRAOSSEOUS (IO) ACCESS
IO access has the advantage of cannulating a noncollapsible structure that connects to the central circulation. IO access is indicated when there is an emergent need for vascular access and other sites are difficult, high risk, or excessively time consuming. Mechanical IO insertion devices have insertion times of only seconds with consistently >90% success rates.1­8 Insertion devices include simple hand­twist needles, hand­held power drills, and spring­loaded devices.
There are few contraindications to IO placement (Table 114­1), and the rate of serious complications from IO insertion is ≤1%. The most common complication is extravasation at the insertion site. By comparison, central venous catheters have complication rates of at least .4%.1,2 Although the indications for IO access are often thought to be limited to unstable patients who need immediate access, IO access is a viable alternative to central venous access in some patients without adequate peripheral access.9
TABLE 114­1
Contraindications to IO Placement
Overlying infection
Exposed bone
Underlying fracture
Structural bone disorders (e.g., osteogenesis imperfecta)
MEDICATIONS AND FLUIDS ADMINISTERED BY THE IO ROUTE
Any medication or fluid that can be given through an IV can be administered by the IO route. Paralytics, anticonvulsants, analgesics, benzodiazepines, and vasopressors such as epinephrine have comparable IO and IV infusion rates. Blood and blood products can be given by the IO route.3 Medications for rapid­sequence intubation can be administered by the IO route, although the time to effect may be delayed.4 In a study of sheep given IV or IO succinylcholine, the IV route induced respiratory arrest in a mean of .8 seconds, whereas the IO route took .5 seconds.5
The principal limitation of IO access is a relatively low maximum flow rate. Resistance to flow within the bone marrow cavity limits the flow rate of IO needles, and flow rates per kilogram tend to be higher in young patients who have a greater percentage of low­resistance red marrow compared to adults. The speed of administration of IO infusions can be improved with pressure devices.
LABORATORY TESTING OF BONE MARROW ASPIRATE
The comparison of marrow aspirate with peripheral blood has been explored in small trials of hematology and oncology patients undergoing routine marrow sampling (Table 114­2). Two of these human studies have shown a close correlation of marrow aspirate to venous blood in regard to hemoglobin, sodium, chloride, bilirubin, pH, bicarbonate, urea, and creatinine concentrations.6,7 In another study, bone marrow taken for medical diagnosis correlated with the peripheral blood for ABO, Rh typing, and leukocyte activity.8 Correlation between bone marrow and peripheral blood is less reliable for leukocytes, platelets, glucose, potassium, aspartate aminotransferase, alanine aminotransferase, alkaline phosphatase, partial pressure of carbon dioxide, and partial pressure of oxygen; however, the degree of discrepancy likely has minimal clinical significance. Aspirates obtained from the marrow after prolonged CPR may be considerably different from serum levels.9
TABLE 114­2
IO Laboratory Findings Compared With Phlebotomy
Equivalent Use Caution in Interpretation
Hematologic Hemoglobin Leukocytes, hematocrit, platelets
Chemistries Sodium, chloride, glucose, bilirubin, bicarbonate, urea, and creatinine Potassium, aspartate aminotransferase, alanine aminotransferase, alkaline phosphatase

ChapVteenro u1s 1ga4s: VaspcHular Access in Infants and Children, Matthew L. HansenPCO2, PO2 
. Terms of Use * Privacy Policy * Notice * Accessibility
Transfusion ABO, Rh typing, and leukocyte activity —
Abbreviations: PCO2 = partial pressure of carbon dioxide; PO2 = partial pressure of oxygen.
IO CANNULATION DEVICES
The two most common manual insertion devices include the Cook® IO needle (Cook Medical, Bloomington, IN) and the Jamshidi® style IO needles. Powered devices are also available for IO needle insertion; two examples are the EZ­IO ® (Vidacare Corp., San Antonio, TX) and the Bone Injection Gun (BIG ®) (Waismed, Ltd., Hertzliya, Israel). There is one prospective randomized study comparing manual to powered insertion devices in pediatrics in the prehospital setting (22 patients), which compared the Jamshidi needle to the BIG. There were no significant differences in time to insertion, which was less than  minute for both devices, or success rate, which was approximately 80% for both devices.10 In general, powered IO devices in pediatrics are rapid to place with minimal training, modestly faster than manual devices, and felt to be easier to use compared to manual devices. Some of the larger clinical studies have involved the EZ­
IO and have demonstrated the efficacy of powered IO access in clinical care.11,12 Data comparing various powered IO devices have generally come from simulation studies from relatively modest sample sizes, and therefore, it is difficult to draw definitive conclusions about individual products.4,6,13 Each manufacturer has specific instructions to use each product that should be carefully reviewed and practiced prior to using such a device on a patient.
PLACEMENT AND INSERTION OF IO NEEDLE
Placement Sites
(See Videos: Intraosseous Line Placement and Intraosseous Line Placement EZ­IO) The ideal location for IO access is a large bone with easily palpable landmarks, a thin cortex, and limited proximity to vital structures. The proximal or distal tibia, distal femur, and proximal humerus are the sites most commonly described. The flat surface of the anteromedial proximal tibia is easily accessible given the paucity of overlying tissue, making it the most commonly accessed site (Figure 114­1). Insert the needle  cm inferior (distal) to the tibial tuberosity to avoid the physeal plate in children. When accessing the distal tibia, enter just superior to the medial malleolus, avoiding the saphenous vein (Figure 114­2), which is located  cm anterior and  cm superior to the malleolus. In adults, the distal tibia has thinner cortex than that of the proximal tibia. The anterior distal femur is an alternate site for children when the proximal tibia cannot be used or has failed (Figure 114­3). Insert the needle two fingerbreadths superior (proximal) to the distal end of the femur in the midline.
Video 114­1: IO Placement Jamshidi Needle
Used with permission from David Cline and Henderson McGinnis, Department of Emergency Medicine, Wake Forest University Baptist Medical Center.
Play Video
Video 114­2: IO Placement EZ­IO
Used with permission from Lori J. Whelan, MD; Christopher Tainter, MD RDMS, University of Oklahoma, School of Community Medicine, Tulsa, OK.
Play Video
FIGURE 114­1. Anatomy of the proximal tibia for IO placement. [Reproduced with permission from Vidacare Corp., San Antonio, TX. For updates see http://www.vidacare.com/ez­io/index.html.]
FIGURE 114­2. Anatomy of the distal tibia site for IO placement.
FIGURE 114­3. Distal femur. The distal femur is an alternative site for IO access. The red circle represents the site of insertion of the intraosseous needle. [Reproduced with permission from Hoffman ME, Ma
OJ: Intraosseous infusion, in Reichman E, Simon RR (eds): Emergency Medicine Procedures. Figure 44­4, http://www.accessemergencymedicine.com/content.aspx?aID=50506.]
Steps for Insertion
Once the appropriate insertion site has been selected, place the IO needle perpendicular to the bone against the skin. Manual needles are pushed into the bone using steady pressure and slow rotation of the needle back and forth. If using a powered device, follow the specific instructions for that device. Some devices (e.g., EZ­IO) come with multiple needle lengths; in general, the shortest needle is used for young infants, and most children will require an adult size (25 mm). After placing the needle, unscrew the stylet from the needle and attach a 5­ or 10­mL Luer­
Lok syringe to the IO needle and aspirate. Return of blood or bone marrow confirms placement, but return does not always occur, even when the needle is properly placed. Flush the IO needle with  to  mL of normal saline, which should flow easily and further confirm placement. If the IO needle has penetrated the posterior cortex or if the tip is not in the medullary cavity for another reason, fluids will extravasate into the soft tissues. This could include spaces posterior to the bone being cannulated, such as the gastrocnemius in a proximal tibial attempt.
Palpate the area carefully to ensure that no extravasation is present. If the needle is misplaced, remove it and select a different bone for subsequent attempts. Frequently, automated gravity­based infusions and even automated pumps may not provide adequate pressure for infusion, and pneumatic pressure bags may be required. Secure the needle with a dressing that stabilizes the needle securely in place to limit the chance of dislodgement, while allowing access to the site to check for extravasation.
COMPLICATIONS OF IO PLACEMENT
The complication rate is low. The most common complication is pain during insertion and infusion. Discomfort during infusion is thought to be due to pressure within the marrow cavity and can be reduced with the administration of lidocaine. The manufacturer of the EZ­IO recommends giving a .5 milligram/kg dose of 2% lidocaine without epinephrine (20 to  milligrams in adults) followed by a 10­mL normal saline flush after the IO route is established.
In a prospective cohort of  patients who had intraosseous IO in the field or in the ED, no complications were noted other than difficulty removing the needle.11 A retrospective series of  patients with IO placement had one serious complication of tibial fracture in a 10­day­old infant.14 A case series of  insertions by a pediatric critical care transport team noted a 12% complication rate, and all complications were minor local tissue edema or infiltration.15 A population­based study found no serious complications in 281 IO insertions using administrative data.16 Case reports have described serious complications including compartment syndrome, osteomyelitis, fat embolism, cerebral air embolism, and skin necrosis from extravasation of caustic medications.16 Soft tissue fluid accumulation may be more likely in the setting of multiple attempts at IO placement in the same bone. As a result, no more than one attempt per bone is recommended.17 Growth plate injuries are possible if not inserted at the proper site.18 Tibial fracture is a rare complication that is more likely in children with underlying bone disorders. In general, radiographs are not needed after IO removal unless there is suspicion of a complication.
IO REMOVAL
Each device has specific instructions for removal. Generally speaking, a syringe can be attached to the needle to remove it. If the syringe is twisted counterclockwise, it will unscrew from the hub, which can be difficult to grasp. Other needles can be removed with traction and a back­and­forth twisting motion. Remove IO needles as soon as another stable route of vascular access is established.
ULTRASOUND (US)­GUIDED PERIPHERAL VENOUS ACCESS IN INFANTS AND CHILDREN
Peripheral venous access with US guidance is an additional option when blind peripheral attempts fail. Both arm and leg veins can be accessed using either a transverse or longitudinal approach to localize the vein and directly guide cannulation. One randomized trial demonstrated significantly reduced time to peripheral venous access with fewer total attempts when US was used compared to traditional techniques in pediatric patients with difficult IV access.13 The saphenous vein has also been described as a reliable site for US­guided IV placement.
However, a large trial found that neither US guidance nor near­infrared vascular imaging improved first attempt success rate when deployed routinely.19 Another study showed no improvement in success when using US after one failed IV attempt among practitioners with little experience using US, which suggests that both operator experience and patient characteristics likely play a significant role in success with this technique.20
CENTRAL VENOUS ACCESS IN INFANTS AND CHILDREN
Central venous access is safe in all age groups as long as proper techniques are followed. In older children, complications are similar to those encountered in adults. Insertion of central venous catheters >6 French in size in children <1 year old, <10 kg in weight, or <75 cm in height is associated with higher complication rates.21 Typically, a 5­French catheter is used for term neonates and infants, and a 3­French catheter is used for preterm (<36 weeks) neonates. With the advent of powered osseous access, the importance of central venous access for many pediatric clinical scenarios has decreased. Indications for pediatric central venous access in the ED are listed in Table 114­3. TABLE 114­3
Indications for Pediatric Central Venous Access
Inability to obtain peripheral access
Need for invasive hemodynamic monitoring
Administration of caustic or hypertonic solutions
Need for long­term vascular access
Need for transvenous pacemaker placement
Rapid large­volume resuscitation is not always an indication for central access. The rate of flow through a catheter is inversely related to the length of the cannula; thus, central lines have slower flow rates than peripheral catheters of the same diameter. However, large­bore central catheters, which are shorter than common multilumen catheters, allow extremely rapid infusion. The choice of central venous catheter size in children should be predicated on the primary disease and intended use as well as the child’s age, weight, and height.
PLACEMENT OF CENTRAL VENOUS CATHETERS
The three most common anatomic locations for obtaining central access in children are the subclavian vein, the internal jugular vein, and the femoral vein (see Chapter , “Vascular Access,” for descriptions of these procedures). The anatomic landmarks and insertion techniques are the same in adults and children, although key differences are described below. The choice of location depends on patient factors as well as practitioner experience with a particular site. Complications of central venous access are listed in Table 114­4. Multiple attempts (more than two) and the subclavian approach are associated with higher complication rates.17 As in adults, ultrasound guidance improves success and reduces complications in pediatric central line placement and is generally recommended.19,22,23
TABLE 114­4
Complications of Pediatric Central Venous Access
Pneumothorax (subclavian and internal jugular vein sites)
Thoracic duct injury (left­sided internal jugular vein)
Arterial puncture
Cardiac tamponade
Air embolism
Arrhythmia
Incorrect position
Hemothorax (subclavian and internal jugular vein sites)
Subcutaneous hematoma (subclavian vein cannulation in coagulopathy)
Neuropathies
Death
Infection
SUBCLAVIAN VEIN
The anatomy of the subclavian vein and technique for line placement are similar in children and adults. The primary disadvantage is a higher rate of mechanical complications of insertion compared to other sites including the relatively high potential for pneumothorax in children given the extension of the lung apices above the clavicles.
Place the child’s head in a neutral position, without the use of a shoulder roll, as this maximizes vein diameter.24 For a detailed explanation of technique, see Chapter . INTERNAL JUGULAR VEIN
The anatomy of the internal jugular vein is similar in adults and children. As in adults, US guidance is recommended in children and likely improves success rates.
In children, the combination of the Valsalva maneuver, liver compression, and Trendelenburg positioning maximizes the distention of the internal jugular vein. For further discussion, see
Chapter . FEMORAL VEIN
The anatomic location of the femoral vein in children is similar to that in adults. In children, as compared to adults, the femoral site may not be associated with higher infection rates and is easier to place in a responsive child, and mechanical complications are less likely to be severe (e.g., pneumothorax and pericardial tamponade).
The femoral artery overlaps the femoral vein at least partially in up to 15% to 20% of children.25,26 US can be used to optimize the patient’s position while improving success rates and reducing complications. For further demonstration of the technique, see Chapter . UMBILICAL VEIN ACCESS
In general, umbilical venous catheterization is limited to the first week of life. The umbilical vein is continuous with the portal vein. An alternative to umbilical access for neonatal resuscitation is IO placement, which may be preferable for those not trained in umbilical access.
UMBILICAL CANNULATION PROCEDURE
Use a .0­French catheter for term infants and a .5­French catheter for preterm infants. For emergency access, insert the catheter only  to  cm in depth. Preflush the catheter and attach it to a closed stopcock connected to a syringe. Use standard iodine­based sterile preparation of the umbilicus and sterile drapes. Tie a string loosely around the skin at the base of the umbilicus; this can be tightened in case of bleeding (Figure 114­4).
FIGURE 114­4. A through D. Umbilical vein access.
Cut the cord with a scalpel approximately  cm from the abdominal wall and identify the vein and two arteries. The vein is larger, thin walled, and usually at the  o’clock position. The arteries are smaller with a thicker muscular layer and located roughly at  and  o’clock. The vein may need to be dilated or thrombus cleared from the lumen with small forceps. Holding the catheter near the tip, insert it into the vein, checking every centimeter for blood return by drawing on the syringe. If resistance is met at the base of the stump, loosen the umbilical tie. In emergency situations, advance the catheter only  to  cm beyond the point of good blood return; this is typically  to  cm from the end of the umbilical stump in a term infant. If there is free return of blood, the line can be used. In this technique, the catheter extends only a few centimeters into the abdomen, so radiographic confirmation is not necessary. At that point, tighten the purse string or umbilical tie and tie it off. A suture may be placed through the stump and tied around the catheter, or the catheter can be held in place manually.
COMPLICATIONS OF UMBILICAL VEIN CANNULATION
Umbilical vein cannulation carries serious risks, which are similar to those for standard central venous catheters but also include more serious complications related to deeper insertion than should be performed in emergencies in the ED where the umbilical line is a bridge to other access. Monitor for tachycardia or signs of increasing abdominal distention, which suggests vessel or bowel perforation.27


