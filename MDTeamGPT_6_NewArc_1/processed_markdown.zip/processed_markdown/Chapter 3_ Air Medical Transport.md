Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e 
Chapter 3: Air Medical Transport
Keith C. Stone; Stephen H. Thomas

INTRODUCTION
Air medical transport consists of helicopter (or rotor­wing) and airplane (or fixed­wing) transport and is an important component of EMS systems for prehospital care and interfacility transport. These specialized vehicles offer fast speeds, ranging from 100 to 200 miles per hour for helicopters to >500 miles per hour for airplanes. Although many ill and injured patients can be transported safely by ground, air medical transport provides added medical assessment and care capabilities beyond those of the paramedic­staffed ground ambulance. Guidelines for the use of air medical transport exist, but field EMS personnel and physicians involved in transfer decision making should be able to consider situational circumstances to determine the appropriate transportation mode.

Weather can be an operational limitation, particularly for helicopters. The radius of service differs between helicopters and fixed­wing craft, but, as a general rule, fixed­wing transport is considered when weather conditions are poor or when transport distances exceed 150 to 200 miles.

The complexity of air transport far exceeds the simple act of loading a patient on an airborne vehicle. National organizations such as the Air Medical
Physician Association, the Committee on Accreditation of Medical Transport Systems, and the National Association of EMS Physicians have published texts, position statements, and guidelines covering aspects of air medical transport. The Air Medical Physician Association (http://www.ampa.org) Air
Medical Physician Handbook is a particularly helpful resource for medical issues. The Committee on Accreditation of Medical Transport Systems
(http://www.camts.org) accreditation standards address medical, aviation, organizational, and operational issues. The National Association of EMS
Physicians (http://www.naemsp.org) has created detailed position statements and guidelines addressing helicopter EMS trauma and nontrauma triage criteria, as well as training of physicians involved as air medical crew or medical directors.

Rigorous training programs, covering both cognitive and procedural skills, enable flight crews to provide a high level of intratransport care . In­flight communications capabilities should include the ability of the air medical crew to speak with medical control physicians, as well as arrange for any change of plan (e.g., direct transport to the operating suite) necessitated by patient condition.

HELICOPTER TRANSPORT
AVIATION ISSUES

Individual hospitals, hospital systems, or private for­profit enterprises run most U.S. civilian air transport programs. Because helicopters are expensive
(ranging from $750,000 to more than $5 million each) and other aviation needs (e.g., maintenance, pilot training) are also resource intensive, most hospital­based programs lease their helicopters from vendors. The air medical program typically provides and equips communications and medical personnel, whereas the aircraft vendor supplies the helicopters, pilots, and maintenance personnel. Although costs vary depending on geographic region, patient case mix, equipment and aircraft used, and even the methods used for their calculation, annual operating costs for a rotor­wing service typically exceed $2 million.

Safety is an overriding consideration for air transport . Optimization of safety begins well before an actual air transport, with training of the flight crew and of those who interact with them at scenes and hospitals. Training is especially important for scene responses, in which the helicopter may be landing in an unknown area with more nearby obstacles (e.g., wires, trees) than the hospital helipad. In addition to providing training for referring agencies, helicopter EMS pilots and medical crew should undergo both initial and recurrent safety training. For added protection, most helicopter EMS programs have followed the lessons of the military experience and adopted injury­prevention maneuvers such as the use of helmets and fire­resistant clothing. As another safety issue, the pilot should be “blinded” to the nature of the call during mission planning; this eliminates the introduction of acuity­related subjectivity as the pilot considers whether the mission should be accepted.

Safety is partially behind the transition of helicopter EMS programs from single­engine helicopters with visual flight rules capability to twin­engine helicopters that can fly under instrument flight rules conditions. The latter aircraft have greater lifting capacity, range, and speed and usually can execute controlled landings in the event of failure of one engine. A visual flight rules aircraft can fly only during good visibility, whereas instrument flight rules aircraft operate safely in poorer conditions; both comply with visibility limitations imposed by the Federal Aviation Administration, but the instrument flight rules helicopter has fewer restrictions. If the pilot unexpectedly encounters bad weather during a flight, an instrument flight rules helicopter (as compared with a visual flight rules aircraft) has a better chance of completing the mission successfully and safely. Due to the complexity of instrument flight rules operations, some programs (especially those with frequent bad weather periods) have elected to use two­pilot instrument flight rules.

Air medical programs operate under rules established by the national aviation authority—in the United States, the Federal Aviation Administration.
Additionally, the industry itself has set forth stringent standards under the auspices of the Committee on Accreditation of Medical Transport Systems.
On request, the Committee on Accreditation of Medical Transport Systems performs site visits of air medical programs to certify that they comply with strict safety and operational (as well as clinical) standards. As of September 2016, 183 U.S. transport programs were accredited by the Committee on
Accreditation of Medical Transport Systems.

AIR MEDICAL CREW
The primary considerations regarding medical members of the flight crew are crew configuration and training. Although there are few absolutes with regard to optimal configuration, initial and recurrent training is at least as important as the credentials of the flight team members.

The air medical team can have multiple compositions: nurse–paramedic, nurse–nurse, nurse–physician, or nurse–respiratory therapist . These differences may be one reason that the literature has failed to answer definitively the seemingly simple question of whether a physician should be on board the helicopter. Most U.S. programs agree that physicians are not a necessary component of helicopter EMS crews, and a recent survey showed that 92% of programs use nurse–paramedic crews. 1

The capabilities of most U.S. nonphysician crews represent an extended scope of practice. For instance, flight paramedics and/or nurses frequently are credentialed to perform such procedures as neuromuscular blockade–assisted endotracheal intubation and cricothyrotomy. This example of extended practice scope is important, given the importance of prehospital airway considerations and the fact that flight crews represent a highly trained group with particular expertise in this area. Reported success rates for nonphysicians are as high as 94.6% for drug­assisted and 97.7% for rapid sequence intubation–assisted endotracheal intubation and 90.9% for surgical cricothyrotomy. 2

At this time, the best recommendation with regard to crew configuration is for programs to continue to do what works for them, as the literature does not report the superiority of a particular model. Most U.S. programs perform a variety of scene and interfacility missions for trauma and nontrauma indications, so the nurse–paramedic configuration, combining the complementary skills of prehospital and hospital­based practitioners, meets their needs. Some transport population heterogeneity can be addressed by the accommodation of extra crew members (e.g., neonatal nurses, intra­aortic balloon pump technicians) when logistics allow. Regardless of the background of the air medical crew, initial and recurrent training in both cognitive and procedural skills is necessary to ensure an optimal level of care.

ENVIRONMENTAL FACTORS OF AIR TRANSPORT
Patient care in any transport vehicle differs from that provided while the patient is on a hospital stretcher. Vehicle vibrations, bumpy rides, noise, physiologic stress, ergonomic constraints ( Figure 3­1 ), and motion sickness are among the factors that can affect monitoring and interventions.

FIGURE 3­1. The patient care compartment in a Dauphin II helicopter.

The impact of most vehicle­related issues in helicopter EMS can be eliminated, or at least reduced. Some solutions are easy (e.g., visual rather than aural alarms on ventilators), but flight crews must learn to “work around” other limitations (e.g., perform preflight intubation on patients who appear likely to deteriorate). Some problems will be specific to a service’s particular aircraft, mission profile, or crew background. Individual program patient care protocols should take into account the service’s equipment and personnel­related capabilities and limitations.

One transport­related issue that cannot be avoided is the question of altitude and its potential effects on the patient and the crew . In fact, altitude considerations vary with location—a Denver­based program has concerns that are different from those of a Miami service. Environmental conditions also have an impact on altitude considerations, because aircraft operating under instrument flight rules frequently fly at higher altitudes than those operating under visual flight rules. Of course, fixed­wing transports have more pronounced altitude considerations.

Helicopter (or fixed­wing) altitude and environment have potential effects on patient pathology as well as the crew’s ability to monitor and care for the patient. Helicopters generally transport patients at about 1000 to 3500 ft above ground level (not necessarily sea level), although sometimes these altitudes are increased for instrument flight rules flights or for clearing of obstacles or terrain. Therefore, altitude­related problems such as hypoxemia, dehydration, and low temperature tend to be mild or relatively easily to overcome. However, geographic differences are important. Some western U.S. programs fly with supplemental oxygen for the medical crews.

Pressure­related problems related to Boyle’s law (the volume of a gas increases when the pressure decreases at a constant temperature) may represent the most important consideration for helicopter­transported patients. For example, even the relatively low transport altitude range for helicopter EMS may affect patients with certain diagnoses (e.g., decompression sickness, cerebral arterial gas embolism) or instrumentation (e.g., tamponading devices for esophageal variceal hemorrhage). Endotracheal intracuff pressures increase an average of 33.9 cm of water at a mean altitude of 2260 ft. 3 This could raise the cuff pressure above the perfusion pressure of the tracheal mucosa, leading to injury. Hand­held commercially available devices can be used to keep cuff pressure within the target range of 20 to 30 cm of water. The devices are held in one hand and connected to the cuff inflation port. An inflation bulb can be used to further inflate the cuff, or an air­release button can be used to remove air while the cuff pressure is simultaneously measured by the device.

In some cases, an understanding of altitude issues is important in preventing complications. To minimize aspiration risk, gastric intubation should be performed for unconscious patients transported by air. Alternatively, understanding of the relevant science can be used to prevent overreaction to potential barometric risks. For example, not all patients with small pneumothoraces who do not otherwise require tube thoracostomy require pretransport chest decompression simply because they are to be transported by air.

CLINICAL USE OF HELICOPTERS
While trauma still constitutes the majority of helicopter transports for most programs, as more time­critical treatments develop, more transports will be arranged for noninjured patients . There are many schemes (age group, scene/interfacility mission type) for categorization of helicopter
EMS transports, but the simplest categorization is into trauma and nontrauma. Logistical issues are important to both categories. Therefore, these are considered first.

LOGISTICS AND HELICOPTER EMS USE
Some logistic prompts for helicopter consideration include (1) lengthy transport time for ground ambulances to reach the tertiary center,
(2) ground vehicle transport time to the local hospital exceeds the time required for helicopter transport to the tertiary center, and
(3) for entrapped trauma patients, extrication time is expected to exceed 20 minutes . In some cases, helicopter EMS is used because local ground EMS personnel lack the expertise to provide the indicated level of intratransport care. Another important consideration is whether a region’s ground EMS system can provide transport to the receiving tertiary center while maintaining the ability to cover its base area with appropriate advanced life support care. Questions that can assist healthcare providers in determining the appropriate transport modality for an individual patient are listed in Table 3­1 .

TABLE 3­1
Questions to Aid in Determining Need for Helicopter Transport
Is minimization of time spent out of hospital important?
Is time­sensitive evaluation and treatment involved, and is it available at the referring facility?
Is the patient inaccessible to ground transport?
What are the transport route weather conditions?
Does the weight of the patient preclude air medical transport?
Are aircraft landing facilities available at or near the referring hospital?
Is critical­care life support required that is not available with ground transport?
Would ground transport leave the local area without adequate EMS coverage?
If local ground transport is not an option, are regional ground critical­care transport services available?

HELICOPTER EMS FOR TRAUMA PATIENTS
There is one group of trauma patients—those in traumatic cardiac arrest —for whom air medical scene response has shown a very low rate of resuscitation and essentially zero survival. 4 Most helicopter EMS programs have their crews accompany traumatic arrest patients by ground to the nearest facility.

After the initial triage response decision, the larger issue is whether helicopter EMS actually improves outcome for any injured patients .
There is disagreement over this question, but multiple studies have shown improved outcomes. 5­8

The recent largest study to demonstrate improved outcomes after traumatic injury related to helicopter transport analyzed 223,475 patients from the
National Trauma Data Bank transported by helicopter (28%) or ground EMS (72%). For trauma patients who were admitted to level I or level II centers, patients transported by helicopter had a significantly improved survival to hospital discharge compared with patients transported by ground transport. 5 Another recent study of 14,440 trauma patients taken to a level I trauma center demonstrated that patients transported by helicopter had a reduced overall mortality and that patients transported by all other means were more likely to die in the ED. 8

The outcomes of rural trauma patients are thought to be worse than those of urban trauma victims. After controlling for age, gender, and Injury
Severity Score, a Utah study 9 of helicopter transports from rural and urban trauma scenes found no difference in mortality. This study demonstrated that the helicopter scene transport of rural trauma victims appears to be a mortality equalizer.

A shortcoming of the literature is that studies generally address only the hard end point of mortality, with little emphasis on either mechanisms for survival improvement or nonmortality end points. Regardless of these shortcomings, the primary issue for trauma helicopter EMS is not whether some patients benefit, but rather how well those patients most likely to benefit from helicopter use can be identified by improved triage criteria. Although definitive criteria are lacking, the National Association of EMS Physicians has published guidelines for clinical situations that are appropriate for air transport ( Table 3­2 ).

TABLE 3­2
Air Transport Indications for Scene Trauma
General and mechanism of injury
Trauma score <12
Unstable vital signs
Significant trauma in patients age <12 or >55 y and pregnant patients
Multisystem injuries
Ejection from vehicle
Pedestrian or cyclist struck
Death in same passenger compartment
Penetrating trauma of the head, neck, chest, abdomen, or pelvis
Crush injury of the head, chest, or abdomen
Fall from height
Near drowning
Neurologic injuries
Glasgow Coma Scale score <10
Mental status deterioration
Obvious skull fracture
Spinal cord injury
Thoracic Injury
Major chest wall injury (e.g., flail chest)
Pneumothorax
Hemothorax
Suspected cardiac injury
Abdominal/pelvic injuries
Significant abdominal pain after injury
Seatbelt sign or abdominal contusion
Rib fractures below the nipple line
Unstable pelvis
Open pelvic fracture
Pelvic fracture with hypotension
Orthopedic injuries
Amputation of limb (partial or complete)
Finger or thumb amputation when replantation is available
Fracture/dislocation with associated vascular compromise
Limb ischemia
Open long­bone fractures
Two or more long­bone fractures
Thermal injury
Burns of >20% body surface area
Burns of face, head, hands, feet, or genitalia
Inhalation injury
Chemical or electrical burns
Burns associated with other traumatic injuries

HELICOPTER EMS FOR NONTRAUMA PATIENTS
The reason that helicopter EMS trauma literature is (relatively) abundant is that there are ready means for controlling for the differing acuities of airand ground­transported patients. Unfortunately, there is no such easy methodology for patients with nontrauma diagnoses, and acuity scales for nontrauma patients generally have not been accepted for use in assessing the association between transport mode and outcome.

Some general guidelines are available ( Table 3­3 ), and the logistic considerations noted previously apply to nontrauma flights. In most helicopter
EMS programs, the largest single nontrauma diagnostic category is cardiac . Patients in cardiac arrest should be transported to the nearest hospital rather than loaded on an aircraft. Transport for primary or rescue coronary intervention for ST­segment elevation myocardial infarction is a frequent indication for helicopter use and can be done rapidly and safely. 10,11 Cardiac patients with pacemakers or those who have received thrombolytic therapy can be transported safely and effectively by helicopter EMS.

TABLE 3­3
Air Transport Indications for Nontrauma Conditions
Cardiac
Acute coronary syndromes
Cardiogenic shock
Cardiac tamponade
Mechanical cardiac disease (cardiac rupture)
Critically ill medical or surgical patients
Pretransport cardiac arrest
Pretransport respiratory arrest
Mechanical ventricular assist
Continuous vasoactive medications
Risk of airway deterioration
Severe poisoning
Need for hyperbaric oxygen treatment
Emergent dialysis
Unstable GI bleeding
Surgical emergencies (e.g., aortic dissection)
Obstetric
Delivery will require obstetric or neonatal care beyond the capabilities of the referring facility
Active premature labor <34 wk or estimated fetal weight <2000 grams
Acute abdominal emergencies <34 wk or estimated fetal weight <2000 grams
Preeclampsia or eclampsia
Third­trimester hemorrhage
Fetal hydrops
Complicated maternal medical conditions
Predicted severe fetal heart disease
Neurologic
CNS hemorrhage
Spinal cord compression
Status epilepticus
Neonatal
Gestational age <30 wk or fetal weight <2000 grams
Supplemental oxygen exceeding 60%, continuous positive airway pressure, or mechanical ventilation
Extrapulmonary air leak, interstitial emphysema, or pneumothorax
Medical emergencies (e.g., congestive heart failure, disseminated intravascular coagulation)
Surgical emergencies (e.g., diaphragmatic hernia, necrotizing enterocolitis)

Another growing indication is the provision of lytic therapy or vascular intervention for ischemic stroke. 12 The American Stroke Association
(http://www.strokeassociation.org) Task Force on Development of Stroke Systems 13 identified helicopter EMS as an important part of stroke systems.
However, a study of 122 patients transported to a stroke center after receiving recombinant tissue plasminogen activator at the referring hospital demonstrated no benefit in patient outcomes in air­transported patients. 14

Obstetric transports are a special consideration for air transport because many high­risk patients are best delivered at tertiary care centers. The question for this population is primarily one of safety during transport. In­flight deliveries are a major resuscitation problem for both mother and infant. Experience has provided some reassurance that the use of helicopter EMS to transport high­risk obstetric patients did not result in deliveries in the back of the helicopter, and neonatal outcomes are not adversely impacted by transport .

FIXED­WING AIR MEDICAL TRANSPORT
Fixed­wing aircraft can serve a wide variety of missions, from urgent to routine, over great distances. Because airplanes land only at airports, they cannot respond to the scene, and fixed­wing transports need ground ambulance connections at both ends of the flight to transport the patient between the hospital and airport. Because of these factors, fixed­wing flights generally take longer to arrange and are uncommonly used for truly emergent patients.

Helicopters are virtually always dedicated as air medical transport vehicles when used by U.S. EMS services, but fixed­wing airplanes used for medical transport may have other roles. When fixed­wing aircraft are used for air medical transport, cabins must be reconfigured. Vendors have developed removable medical equipment modules that can be placed relatively quickly in the aircraft cabin.

On a per­mile basis, fixed­wing transports are less expensive than helicopter EMS transports. However, the optimal transport radius for fixed­wing triage varies with regional and patient­specific considerations. The appropriate aircraft to use for any one mission depends on many factors: distance, the nature of the airport at the patient’s pickup point, the condition of the patient, the amount of equipment, and the crew required in transport. A larger plane that can be pressurized can fly above 3000 m (10,000 ft), which means that the aircraft can travel faster, farther, and more comfortably. At these higher altitudes, flight crews must have a deeper understanding of altitude physiology issues. Cabin pressure (i.e., indicated altitude above sea level) should be recorded on medical records because of the importance of pressure issues to physiology, and crew safety training should include measures to take in case of inadvertent cabin depressurization.

All fixed­wing services must comply with civil aviation authority rules for airplanes. The Commission on Accreditation of Medical Transport Systems has developed standards for air medical fixed­wing transport. These standards, which are also a useful primer for more detailed information about fixedwing air medical transport, deal with aircraft configuration, medical equipment requirements, medical crew configuration and training, and medical director qualifications.

MEDICAL DIRECTION OF AIR MEDICAL SERVICES
Medical direction may be even more important with rotor­ and fixed­wing services than with ground services; it is certainly more complicated because it involves most aspects of ground EMS in addition to vehicle­specific and altitude­ and acuity­related issues. The medical director should be familiar with the physiology and stress of flight on patients and should oversee the teaching of these and other applicable principles to the air medical crew.
Overall, a flight crew requires more initial and ongoing training than do most ground EMS personnel due to the higher patient acuity and extended practice scope . Because flight crews are often far from their base of operations and may be out of voice contact, they must be sufficiently trained so that they can act independently when necessary. For nonphysician crew, standing orders or protocols (especially for advanced procedures such as cricothyrotomy) are needed. Periodic review and updating of these protocols, as well as close inspection of every transport record, are among the many responsibilities of the medical director. The Air Medical Physician Association and the National Association of EMS Physicians have published information on the responsibilities and function of the air medical program physician director.
