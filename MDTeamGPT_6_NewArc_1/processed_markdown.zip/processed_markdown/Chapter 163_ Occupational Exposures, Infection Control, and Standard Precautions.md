## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 163: Occupational Exposures, Infection Control, and Standard Precautions
Charissa B. Pacella
INTRODUCTION
The U.S. Occupational Safety and Health Administration defines occupational exposure as a “reasonably anticipated skin, eye, mucous membrane, or
 parenteral contact with blood or other potentially infectious materials that may result from the performance of the employee’s duties.” Blood covers

“human blood, blood products, or blood components.” Other potentially infectious materials are “human body fluids, such as saliva, semen, and vaginal secretions; cerebrospinal, synovial, pleural, pericardial, peritoneal, and amniotic fluids; any body fluids visibly contaminated with blood; unfixed human tissue or organs; HIV [human immunodeficiency virus] or HBV [hepatitis B virus] containing cell or tissue cultures, culture mediums, or
 other solutions; and all body fluids where it is difficult or impossible to differentiate between body fluids.” Healthcare workers should treat all bodily secretions, fluids, and tissues as potentially infectious.
The Hospital Infection Control Practices Advisory Committee of the Centers for Disease Control and Prevention lists select infections and conditions
2­4 that may be encountered in the ED, along with recommended occupational exposure precautions. The concept of standard precautions is built on the premise that healthcare workers cannot readily identify patients who are infected or at risk for infection. Using infection control practices and personal protective equipment during all patient care activities is key.
U.S. Occupational Safety and Health Administration federal regulations prescribe safeguards to protect workers and reduce risk of exposure to blood
 and body fluids. The Centers for Disease Control and Prevention and U.S. Occupational Safety and Health Administration websites provide the most up­to­date information regarding current regulations and standards.
PORTALS FOR EXPOSURE
Portals for infectious disease entry are percutaneous, mucous membrane (oral, ocular, nasal, vaginal, or rectal), respiratory, and dermal. The risk of infection in an exposed healthcare provider depends on (1) the route (portal) of exposure, (2) the concentration (number of organisms) of the pathogen in the infectious material, (3) the infectious characteristics (virility) of the pathogen, (4) the volume (dose) of infectious material, and (5) the immunocompetence (susceptibility) of the exposed individual.
Percutaneous exposures pose the highest risk of transmission for bloodborne disease. Needle sticks and lacerations by sharp objects account for most percutaneous injuries. Phlebotomy, initiation of IV access, manipulation of access devices, suturing, and medication injection all put workers at risk.
Mucous membrane exposures result from splatters, splashes, and sprays of blood and body fluids. Tasks associated with risk of mucous membrane exposure include wound management (hemorrhage control, exploration, irrigation, debridement), airway suctioning, nasogastric or orogastric tube placement, intubation, and specimen handling.
Respiratory exposures occur through inhalation of airborne or droplet particulate materials. Exposure risk grows when an individual is confined with an expectorating, coughing, or sneezing patient for prolonged periods or in a poorly ventilated environment.
Dermal exposure involves skin contact with patients, environmental surfaces, or objects contaminated with infectious material. The risk of infection increases if the contact involves a large surface area or nonintact skin (abraded, chapped, or excoriated). Drug­resistant organisms (e.g., methicillinresistant Staphylococcus aureus, vancomycin­resistant enterococci) and parasites of the integument (e.g., scabies, lice) are transmitted by dermal exposure. Many workplace activities risk dermal exposure including patient examination, moving patients, and changing linens and wound dressings.
Healthcare workers are also at risk for hypersensitivity reactions to specific inert substances, notably latex, after prolonged or repeated dermal eDxopwonsluoraed.ed 2025­7­1 6:20 P Your IP is 136.142.159.127
Chapter 163: Occupational Exposures, Infection Control, and Standard Precautions, Charissa B. Pacella 
. Terms of Use * Privacy Policy * Notice * Accessibility
INFECTION CONTROL
Infection control practices seek to prevent transmission of microbial agents and to provide a wide margin of safety for healthcare workers. These practices include hand hygiene; use of personal protective equipment; cleaning, disinfecting, and sterilizing patient care equipment and environmental surfaces; decontamination and laundering of soiled uniforms, clothing, and linens; disposal of needles, sharps, and infectious waste; and patient location. Infection control measures that are simple, easily accessible, and uniform across all situations have the greatest likelihood of compliance.
A complete infection control program includes administrative controls, equipment engineering, work practice controls, workforce education, and medical management.
Administrative controls organize, define, and direct infection control activities. The written infection control (exposure) plan defines policies, procedures, and activities related to the education, prevention, and management of infectious diseases in the workforce.
Equipment engineering reduces employee exposure by removing hazards or isolating healthcare workers from exposure. Examples include selfsheathing needles, needleless drug administration devices, sharps containers, disposable airway equipment, and personal protective equipment.
Personal protective equipment is “specialized clothing or equipment which does not permit blood or potentially infectious substances to pass through or reach worker clothing, skin, eyes, mouth, or other mucous membranes under normal conditions of
 use.” Personal protective equipment includes examination gloves, facemasks, eye protection, face shields, and impervious gowns, leggings, and shoe covers. Personal protective equipment reduces but does not eliminate exposure risk. Recommendations for specific personal protective equipment use appear under “Standard Precautions.”
Work practice controls modify the performance of a task to minimize exposure to blood and blood­containing body fluids and infectious materials.
Work practice controls include policies to guide disposal of needles and sharps containers (i.e., avoid shearing, bending, recapping, or breaking); disposal of contaminated linens, clothing, and infectious waste; disinfection of reusable equipment; and restriction of employee activities (i.e., eating, drinking, applying cosmetics) in work areas where there is a reasonable likelihood of exposure to blood and body fluids.
Workforce education includes information about the agents of infectious disease, epidemiology, disease transmission, signs and symptoms, risky work activities, risk reduction strategies, and postexposure management. Education must occur at the time of initial employment and at specified intervals thereafter.
Medical management practices include preexposure preventive vaccinations, postexposure medical evaluation, testing, infectious disease counseling, disease prophylaxis, and referral. The U.S. Occupational Safety and Health Administration mandates preexposure vaccines at initial
 employee training and within  days of employment for all personnel at risk of exposure.
EXPOSURE TO HEPATITIS B, HEPATITIS C, AND HUMAN IMMUNODEFICIENCY VIRUS
Once an infectious exposure has occurred, healthcare workers should have access to a plan for postexposure prophylaxis (PEP) medical management
 hours a day. The plan should include immediate medical assessment, risk analysis, counseling, treatment and prophylaxis, and follow­up
6­11  appropriate to the type and source of the exposure. A standardized initial approach is shown in Table 163­1. TABLE 163­1
Outline for Management of Exposures to Blood or Body Fluids
Expedite medical evaluation.
Irrigate exposed areas with water; wash wounds with soap and water.
Obtain history regarding exposure circumstances, source patient, and vaccination history of exposed person (Table 163­2).
Obtain blood samples for laboratory studies (using consents when required) from exposed person; consider urine pregnancy test for women of childbearing potential.
Order laboratory studies from source patient if known (using consents when required).
Determine need for tetanus immunization.
Determine need for hepatitis B PEP (Table 163­5).
Determine need for human immunodeficiency virus PEP (Table 163­6) and mechanism for dosing as rapidly as possible.
Counsel exposed person regarding risk of specific bloodborne pathogens and discuss risks/benefits of available treatment options.
Review dosing and side effects of recommended treatments (Table 163­7).
Arrange follow­up through employee health clinic within  h. Obtain expert consultation in appropriate cases (Table 163­8).
Abbreviation: PEP = postexposure prophylaxis.
The medical record of care for the exposed person (the occupational exposure report) should contain specific information relative to the exposure incident. Key elements include the circumstances of exposure, medical history of the exposure source, and medical history of the exposed person per

Centers for Disease Control and Prevention recommendations (Table 163­2).
TABLE 163­2
Recommendations for the Contents of the Occupational Exposure Report
Date and time of exposure.
Details of the procedure being performed, including where and how the exposure occurred; if related to a sharp device, the type and brand of device and how and when in the course of handling the device the exposure occurred.
Details of the exposure, including the type and amount of fluid or material and the severity of the exposure (e.g., for a percutaneous exposure, depth of injury and whether fluid was injected; for a skin or mucous membrane exposure, the estimated volume of material and the condition of the skin
[e.g., chapped, abraded, intact]).
Details about the exposure source (e.g., whether the source material contained hepatitis B virus, hepatitis C virus, or HIV; if the source is HIV infected, the stage of disease and prognosis, history of antiretroviral therapy, viral load, and antiretroviral resistance information, if known).
Details about the exposed person (e.g., hepatitis B vaccination and vaccine­response status).
Details about counseling, postexposure management, and follow­up.
Abbreviation: HIV = human immunodeficiency virus.
INITIAL TREATMENT AND ASSESSMENT
Thoroughly wash exposed wounds and skin sites with soap and water, and then irrigate mucous membranes with water. Do not apply caustics
(bleach), antiseptics, or disinfectants directly to the wound.
Evaluate the exposure event for the potential to transmit hepatitis B virus, hepatitis C virus, and human immunodeficiency virus (HIV) based on the type
 of exposure and the amount and type of fluid or tissue (Table 163­3). Blood, fluid containing visible blood, human tissue, and other potentially infectious materials may transmit bloodborne viruses. Percutaneous injury or mucous membrane contact with these substances conveys risk for virus transmission. Dermal contact with these substances does not convey risk of virus transmission unless the skin is not intact (abraded, chapped, excoriated, open wound). Saliva, sweat, tears, vomit, urine, feces, and respiratory secretions do not transmit HIV unless visibly bloody. The risk of hepatitis B and C virus transmission from nonbloody saliva is negligible.
TABLE 163­3
Factors to Consider in Assessing Healthcare Workers After Occupational Exposures
Type of exposure
Percutaneous injury
Mucous membrane exposure
Nonintact skin exposure
Bites resulting in blood exposure to either person involved
Type and amount of fluid/tissue
Blood
Fluids containing blood
Potentially infectious fluid or tissue (semen; vaginal secretions; and cerebrospinal, synovial, pleural, peritoneal, pericardial, and amniotic fluids)
Direct contact with concentrated virus
Infectious status of source
Presence of hepatitis B surface antigen
Presence of HCV antibody
Presence of HIV antibody
Susceptibility of exposed person
Hepatitis B vaccine and vaccine response status
HBV, HCV, and HIV immune status
Abbreviations: HBV = hepatitis B virus; HCV = hepatitis C virus; HIV = human immunodeficiency virus.
TESTING FOR EXPOSURE
Perform diagnostic testing to determine the hepatitis B virus, hepatitis C virus, and HIV infection status of an exposure source as soon as possible and
 with consent when required (Table 163­4). If possible, obtain a rapid HIV­antibody test on the exposure source. Direct viral assays (HIV p24 antigen enzyme immunoassay, HIV RNA, hepatitis C virus RNA) are not recommended. Testing of needles or sharps instruments for contamination is also not recommended. If the exposure source is HIV positive, obtain additional information as available, including CD4+ T­cell count, viral load, current and previous antiretroviral therapy, and history of antiretroviral resistance to help identify optimal PEP regimen. Do not delay the initiation of PEP awaiting
 additional information; changes in the regimen may be made upon follow­up within  hours after exposure.
TABLE 163­4
Evaluation of Occupational Exposure Source
Known sources
Test known source for hepatitis B surface antigen, anti–hepatitis C virus, and HIV antibody.
Direct virus assays for routine screening of source patients are not recommended.
If possible, a rapid HIV­antibody test.
If the source person is not infected with a bloodborne pathogen, baseline testing or further follow­up of the exposed person is not necessary.
For source whose infection status remains unknown (e.g., the source person refuses testing), consider medical diagnoses, clinical symptoms, and history of high­risk behaviors.
Do not test needles or instruments for bloodborne pathogens.
Unknown source
For unknown source, evaluate the likelihood of exposure to a source at high risk for infection.
Consider likelihood of bloodborne pathogen infection among patients in the exposure setting.
Abbreviation: HIV = human immunodeficiency virus.
HEPATITIS B VIRUS EXPOSURE AND POSTEXPOSURE PROPHYLAXIS
Factors in the management of hepatitis B virus exposure include the hepatitis B surface antigen status of the source and the hepatitis B vaccination and vaccine response status of the exposed person. Following a percutaneous exposure, the estimated risks of hepatitis in unvaccinated healthcare workers are 22% to 31% (exposure source positive for hepatitis B surface antigen and hepatitis B e antigen) and 1% to 6% (exposure source positive for hepatitis B surface antigen and negative for hepatitis B e antigen). The estimated risk of transmission is lower after mucous membrane exposure,
 nonintact skin exposure, or an exposure involving nonbloody fluids or tissues. Every unvaccinated healthcare worker exposed to blood or body fluids should receive the hepatitis B vaccine series. For vaccinated workers, recommendations for PEP following hepatitis B virus exposure vary according to
 the hepatitis B surface antigen status of the exposure source and the vaccination/vaccine­response status of the exposed person (Table 163­5). If choosing hepatitis B immunoglobulin therapy, give it as soon as possible after the exposure, ideally within  hours; after  days, the effectiveness of hepatitis B immunoglobulin is unknown.
TABLE 163­5
Postexposure Prophylaxis for Percutaneous and Mucous Membrane Exposure to Hepatitis B Virus
Treatment
Vaccination and Antibody Response
Source Is
Status of Exposed Workers Source Is Unknown or Not Available for
Source Is HBsAg Positive HBsAg
Testing
Negative
Unvaccinated/nonimmune HBIG* ×  and initiate HB vaccine Initiate HB Initiate HB vaccine series series vaccine series
Previously vaccinated
Previously vaccinated known responder† No treatment No treatment No treatment
Previously vaccinated known HBIG ×  and initiate revaccination or No treatment If known high­risk source, treat as if source nonresponder‡ HBIG × 2# were HBsAg positive
Previously vaccinated antibody response Test exposed person for anti­HBsƒ No treatment Test exposed person for anti­HBsƒ unknown
. If adequate,† no treatment is . If adequate,† no treatment is necessary necessary ‡
. If inadequate, administer vaccine
‡
. If inadequate, administer HBIG booster and recheck titer in 1–2 mo
×  and vaccine booster
Note: Ideally, HBIG and first vaccination should be initiated within  hours of exposure. Persons who have previously been infected with hepatitis B virus are immune to reinfection and do not require postexposure prophylaxis.
Abbreviations: HB = hepatitis B; HBIG = hepatitis B immunoglobulin; HBsAg = hepatitis B surface antigen.
*Dose is .06 mL/kg IM.
†A responder is a person with adequate levels of serum antibody to HBsAg (i.e., anti­HBs ≥10 mIU/mL).
‡
A nonresponder is a person with inadequate response to vaccination (i.e., serum anti­HBs <10 mIU/mL).
#The option of giving one dose of HBIG and reinitiating the vaccine series is preferred for nonresponders who have not completed a second three­dose vaccine series. For persons who previously completed a second vaccine series (≥6 doses) but failed to respond, two doses of HBIG are preferred given  month apart.
ƒAntibody to HBsAg.
HEPATITIS C VIRUS EXPOSURE
For occupational hepatitis C virus exposures, the Centers for Disease Control and Prevention recommends anti–hepatitis C virus testing of the source patient. Test the exposed person for anti–hepatitis C virus and alanine aminotransferase at baseline and follow­up (at  to  months), and testing for hepatitis C virus RNA may be performed at  to  weeks after exposure if needed to aid early diagnosis of hepatitis C virus. Confirm all positive anti– hepatitis C virus tests by enzyme immunoassay with supplemental testing (i.e., recombinant immunoblot assay). If the source patient is hepatitis C virus infected, the mean estimated risk of transmission is .8% after a percutaneous exposure (range, 0% to 7%). Estimated risk of transmission is
 lower following mucous membrane exposure, nonintact skin exposure, or exposure to nonbloody fluids or tissues. Immunoglobulin and antivirals are not recommended for PEP after exposure to hepatitis C virus–positive blood.
Healthcare workers exposed to hepatitis B virus– or hepatitis C virus–infected blood do not need to take any precautions to prevent secondary transmission during the follow­up period; however, they should not donate blood, plasma, organs, tissue, or semen.
HIV EXPOSURE AND POSTEXPOSURE PROPHYLAXIS
Healthcare workers potentially exposed to HIV should receive expedited evaluation and baseline testing for HIV. Factors in the management of HIV exposure include the type of exposure (percutaneous, mucous membrane, or dermal), the volume of the exposure (small or large), and the HIV status of the source. Risk of HIV transmission following percutaneous exposure increases with exposure to a larger quantity of blood as indicated by (1) a device visibly contaminated with blood, (2) a needle placed in the source patient’s artery or vein, (3) a large­bore hollow needle, or (4) a deep
,13 injury. If the source patient is HIV infected, the estimated risk of transmission is .3% after a percutaneous exposure and .09% after a mucous membrane exposure. Estimated risk of transmission following a nonintact skin exposure or an exposure involving nonbloody
 fluids or tissues is even lower.
If the source patient has a negative HIV antibody test, baseline testing and further follow­up of the exposed person are not normally necessary. If the source patient has a positive HIV antibody test, consider the source to be HIV positive regardless of viral load for the purpose of PEP and follow­up testing. Exposure to a source patient with an undetectable viral load does not eliminate the possibility of HIV transmission. If the source patient is suspected to have acute retroviral syndrome, consider the source to be HIV positive regardless of HIV test result.
Initiate PEP as soon as possible after the exposure; if later testing determines the source to be HIV negative, discontinue prophylaxis. PEP is less effective if started more than  to  hours after exposure. The interval after which no benefit is gained is unknown, so start PEP even when the postexposure interval exceeds  hours.

The U.S. Public Health Service provides guidelines for PEP following occupational exposure to HIV. Guidelines recommend three (or more) tolerable antiretroviral drugs for all occupational exposures to HIV (Tables 163­6 and 163­7). Anticipate side effects and consider preemptive prescribing of
 ameliorating medications to improve PEP regimen adherence. Also, consult with a local expert or with the National Clinician Consultation Center (1­
888­448­4911;  am to  pm daily) for the more complex situations listed in Table 163­8. Do not delay initiation of postexposure therapy awaiting expert consultation; PEP may be started immediately and discontinued later based on new information or consultation. The optimal duration of PEP is
 unknown, but the Centers for Disease Control and Prevention recommends  weeks of treatment.
TABLE 163­6
Human Immunodeficiency Virus (HIV) Postexposure Prophylaxis (PEP) Regimens
Preferred HIV PEP Regimen
Truvada® (tenofovir DF 300 milligrams + emtricitabine 200 milligrams once daily) PLUSraltegravir (400 milligrams twice daily) ordolutegravir (50 milligrams once daily)
Duration:  days
Alternative Regimens
May combine  drug or drug pair from the left column with  drug or drug pair from the right column. Prescribers unfamiliar with these agents/regimens should consult with a physician familiar with these agents and their toxicities.
Raltegravir Tenofovir disoproxil fumarate + emtricitabine (Truvada®)
Dolutegravir Tenofovir disoproxil fumarate + lamivudine
Darunavir + ritonavir Zidovudine + lamivudine (Combivir®)
Etravirine Zidovudine + emtricitabine
Rilpivirine
Atazanavir + ritonavir
Lopinavir/ritonavir (Kaletra®)
Other alternative antiretroviral regimens should be used for PEP only with expert consultation.
TABLE 163­7
Drugs Commonly Used for Human Immunodeficiency Virus Postexposure Prophylaxis (PEP)
Drug (Trade
Name; Dosage Advantages/Disadvantages
Abbreviation)
Tenofovir DF 300 milligrams once daily Well tolerated. Asthenia, headache, diarrhea, nausea, vomiting
(Viread®; TDF) Also component of fixed­dose combinations: Nephrotoxicity; should not be administered to individuals with acute or
Atripla®, Complera®, Stribild®, Truvada® chronic kidney injury, or estimated glomerular filtration rate <60 mL/min/1.73 m2
Withdrawal may cause acute hepatitis exacerbation in the setting of chronic hepatitis B
Emtricitabine 200 milligrams daily Well tolerated, minimal toxicity
(Emtriva®; FTC) Also component of fixed­dose combinations: Skin discoloration, withdrawal may cause acute hepatitis exacerbation in the
Complera®, Stribild®, Truvada® setting of chronic hepatitis B
Raltegravir 400 milligrams twice daily Well tolerated, minimal toxicity
(Isentress®; RAL) Insomnia, nausea, fatigue, headache, severe skin and hypersensitivity reactions
Dolutegravir  milligrams once daily Well tolerated
(Tivicay®; DTG) Headache, insomnia
Zidovudine 300 milligrams twice daily Side effects common and may impact adherence: nausea, vomiting,
(Retrovir®; ZDV, Also component of fixed­dose combinations: generic headache, insomnia, fatigue
AZT) lamivudine/zidovudine, Combivir®, Trizivir® Anemia, neutropenia
Lamivudine 150 milligrams twice daily Well tolerated, minimal toxicity
(Epivir®; 3TC) Also component of fixed­dose combinations: generic Rash lamivudine/zidovudine, Combivir®, Epzicom®, Withdrawal may cause acute hepatitis exacerbation in the setting of chronic
Trizivir® hepatitis B
Lopinavir/ritonavir LPV/RTV 200/50 milligrams =  tablets twice daily GI intolerance, diarrhea, nausea, and vomiting are common
(Kaletra®; PR and QT prolongation reported
LPV/RTV) Potential for serious or life­threatening drug interactions
Note: For more information regarding dosing, side effects, drug–drug interactions, toxicity, and monitoring, see “Antiretroviral Drug Tables” in the Pharmacy section of the National Clinician Consultation Center website (http://nccc.ucsf.edu/clinical­resources/hiv­aids­resources/pharmacy/).
TABLE 163­8
Situations for Which Expert Consultation for Human Immunodeficiency Virus (HIV) Postexposure Prophylaxis (PEP) Is Recommended
Delayed exposure report (>72 h after exposure)
Unknown source (e.g., needle in a sharps disposal container or laundry)
Decide PEP case by case based on epidemiologic likelihood of HIV exposure.
Do not test needles or instruments.
Known or suspected pregnancy or breastfeeding in the exposed person
Provision of PEP should not be delayed awaiting expert consultation.
Toxicity of the initial PEP regimen
Symptoms are often manageable without changing regimen by prescribing antimotility or antiemetic agents. Counseling and support are encouraged because anxiety may worsen side effects.
Serious medical illness in the exposed person
Significant underlying illness (e.g., renal disease) or an exposed person already taking multiple medications may increase the risk of toxicity and drug interactions.
Expert consultation can be made with local experts or by calling the National Clinician Consultation Center at 1­888­448­4911. Following an exposure to HIV, advise healthcare workers to be reevaluated within  hours to assess information about the source patient. Also, emphasize the importance of adherence to the PEP regimen for the duration of treatment. Similarly, recommend that all exposed healthcare personnel prevent potential secondary transmission, especially during the first  to  weeks after exposure, by doing the following: use condoms or exercise sexual abstinence; refrain from donating blood, plasma, organs, tissue, or semen; avoid pregnancy; and, if possible, avoid breastfeeding.
Advise exposed workers to seek medical evaluation for any acute illness that occurs during the follow­up period, as this may signal the onset of acute retroviral syndrome. Follow­up testing includes HIV testing at baseline and at  weeks,  weeks, and  months after exposure, usually concluded  months after the exposure if a newer fourth­generation HIV p24 antigen–HIV antibody test is negative.
RESOURCES FOR POSTEXPOSURE PROPHYLAXIS
The National Clinician Consultation Center offers telephone consultation for providers managing occupational exposures to bloodborne pathogens
(1­888­448­4911;  am to  pm daily). Additional resources and recommendations are available on the center’s website (http://www.nccc.ucsf.edu).
OTHER COMMON OCCUPATIONAL EXPOSURES
Other infectious diseases require special precautions, preventive measures, and postexposure care to minimize the risk of occupational exposure.
Common sources of other occupational exposures are listed in Table 163­9. Maintain high suspicion for disease in populations at risk, and institute isolation precautions promptly when disease is considered.
TABLE 163­9
Other Common Occupational Exposures
Vaccine Employee
Infective Infection Control and
Disease Availability Vaccination and Postexposure Management
Material PPE* and Efficacy Testing
Tuberculosis Aerosolized Airborne precautions Yes (BCG) Vaccine not Approximately 20% of exposed people bacilli and Limited recommended in become infected.
respiratory efficacy U.S. CDC recommended prophylactic treatment secretions Widely used Routine testing after exposure, but research does not support outside U.S. (PPD) for those in that practice.14
Not high­risk areas recommended every 6–12 mo in U.S.
Measles Respiratory Airborne precautions Yes Primary Previously unvaccinated individuals:
(rubeola) secretions Highly immunization Vaccine may prevent disease if given within  and droplet effective recommended h of exposure.
nuclei Monovalent or  doses >4 wk IG conveys temporary immunity and may combination apart prevent or modify disease if given within  d of exposure.15,16
Mumps Respiratory Droplet precautions Yes Primary Previously unvaccinated individuals: secretions Highly immunization Vaccine is unlikely to prevent disease but is effective recommended not harmful and may protect in case of future
Monovalent or  doses >4 wk exposure.
combination apart IG is not effective and not recommended.15
Rubella Respiratory Droplet and contact Yes Primary Previously unvaccinated individuals: secretions precautions Highly immunization Vaccine is unlikely to prevent disease but is and contact effective recommended not harmful and may protect in case of future
Monovalent or  doses >4 wk exposure.
combination apart IG is not effective and not recommended.15
Varicella zoster Respiratory Airborne and contact Yes Immunization (or Previously unvaccinated individuals:
(herpes zoster, secretions precautions† Highly evidence of Vaccine may prevent infection.
chickenpox, and aerosols effective immunity) VZIG conveys temporary immunity and may shingles) from recommended17,18 prevent or modify disease if given within  d.
vesicular Employee should be on furlough from day fluid 10–21 following exposure.17
Influenza Respiratory Droplet precautions Yes Annual Individuals not vaccinated within the past secretions Recommend exclusion or Efficacy varies immunization year: reassignment of annually recommended19,20 Vaccine will not prevent disease but is not employees who are ill with harmful and may protect in case of future fever and respiratory exposure.
symptoms Consider oseltamivir or zanamivir for chemoprophylaxis in higher­risk employees who experience a significant influenza exposure.21
Meningococcus Respiratory Droplet precautions Yes None Chemoprophylaxis should be reserved for secretions Not recommended individuals who performed mouth­to­mouth, recommended intubated, or suctioned the patient without a without mask in the setting of confirmed specific meningococcus.23,24 indication22 Rifampin  milligrams/kg (max 600 milligrams/dose) every  h for  d
Ceftriaxone 250 milligrams in single dose
Ciprofloxacin 500 milligrams in single dose
Severe acute Respiratory Airborne and contact None None No disease­specific recommendations respiratory secretions precautions available recommended syndrome25 and droplet Eye shield nuclei
Scabies (mites) Direct and Contact precautions None None available No disease­specific recommendations indirect contact
Pediculosis Direct and Contact precautions None None available No disease­specific recommendations
(lice) indirect contact
Abbreviations:BCG = bacillus Calmette­Guérin; CDC = Centers for Disease Control and Prevention; IG = immunoglobulin; PPD = purified protein derivative; PPE = personal protective equipment; VZIG = varicella zoster immunoglobulin.
*Standard precautions should always be applied in addition to other recommended precautions.
†If all skin lesions can be covered completely, then contact precautions alone are acceptable.
INFECTION PRECAUTIONS
The Centers for Disease Control and Prevention’s Hospital Infection Control Practices Advisory Committee promulgates two tiers of precautions: standard and transmission based. Standard precautions assume a broad approach to healthcare personnel and patient protection by including agents transmitted by routes other than blood. Transmission­based precautions are designed for patients with documented or suspected transmissible pathogens for which additional protection beyond standard precautions is required. Transmission­based precautions are of three types: airborne,
2­4 droplet, and contact. Transmission­based precautions are to be used in addition to, not in place of, standard precautions.
STANDARD PRECAUTIONS
Standard precautions are exercised when caring for all patients and include hand hygiene (washing or sanitizing), gloves, mask and eye protection or face shield, gowns, handling of patient care equipment and linens, environmental controls, workplace controls, and patient location or placement depending on the indication.
Hand hygiene with soap and water or alcohol­based hand sanitizer is one of the most important ways to prevent the spread of infection. The World
Health Organization recommends that healthcare workers clean their hands: (1) before touching a patient, (2) before a clean/aseptic procedure, (3)
 after body fluid exposure/risk, (4) after touching a patient, and (5) after touching a patient’s surroundings. Using sterile or nonsterile gloves does not eliminate the need for hand hygiene; hand hygiene should be performed both before and after gloves are used. It may also be necessary to clean hands between procedures on the same patient to prevent cross­contamination. Alcohol­based gel and foam products are recommended for most routine hand hygiene due to lesser time burden (which may increase adherence) and greater reduction in bacterial counts as compared with regular
 and antimicrobial soap. However, some pathogens, such as Clostridium difficile, are not eradicated by alcohol­based antiseptics. Scrubbing and rinsing with soap and water is recommended whenever there is visible soiling of the hands or concern for C. difficile.
Gloves
Use clean, nonsterile gloves whenever there is a chance of touching blood, body fluids, secretions, excretions, and contaminated items. Change gloves between tasks and procedures involving blood or other potentially infectious materials. Remove gloves and clean hands before touching noncontaminated items or environmental surfaces (e.g., phones, light switches, writing implements) or other patients.
Masks and Shields
Facemasks, eye protection, and face shields that are fluid resistant are worn to protect mucous membranes of the eyes, nose, and mouth during patient care activities and procedures likely to generate splashes or sprays of blood, body fluids, secretions, excretions, and infectious materials.
Examples of tasks for which masks or shields are recommended include hemorrhage control, airway management, needle decompression, childbirth,
 and nasogastric tube placement. Replace masks that are soiled, moistened by the user’s exhaled vapor, or contaminated by fluids as soon as possible. Protective function may be lost when the barrier device is saturated.
Gowns
Clean, nonsterile gowns that are fluid resistant protect the worker’s skin and clothing during patient care activities and procedures likely to generate splashes or sprays of blood, body fluids, secretions, and excretions. Sample tasks for which impervious gown is recommended include profuse GI bleeding, hemorrhage control, trauma resuscitation, and childbirth. Replace soiled gowns as soon as possible because barrier protection is lost if the garment is saturated. Use sleeve protectors, booties, and leggings when exposure to a large volume of contamination is anticipated.
Disposal
Handle patient care equipment and linens soiled with blood, body fluids, secretions, and excretions specifically to avoid skin and mucous membrane exposure, contamination of clothing, and transfer of microorganisms to other patients and environments. Reusable items should be cleaned and reprocessed to eliminate infectivity. Promptly discard single­use items.
ENVIRONMENTAL AND WORK PRACTICE CONTROLS
Environmental controls include hospital procedures for the decontamination of objects in patient care areas. Clean and disinfect environmental surfaces, beds, bed rails, bedside equipment, and frequently touched surfaces between patient uses.
Workplace controls (work practice controls) include proper disposal of needles and other sharp instruments. Avoid recapping, excessive handling, and manipulation of sharp devices. Use safety devices when available, and replace sharps containers before they overflow. Patients who contaminate the environment or cannot assist in their own hygiene should be located in a private room when possible.
AIRBORNE PRECAUTIONS
In addition to standard precautions, use airborne precautions for patients known to be infected or suspected of being infected with microorganisms transmitted by airborne droplet nuclei. Airborne precautions also apply to small­particle (<5 µm) residue of evaporated droplets containing microorganisms that remain suspended in the air and can be widely dispersed by air currents. Examples of infectious agents spread by this method are
 listed in Table 163­10. TABLE 163­10
Airborne­Spread Infectious Diseases
Rubeola (measles)
Varicella (including disseminated zoster)
Tuberculosis
ISOLATION
Isolate ED patients requiring airborne precautions in an airborne infection isolation room with (1) monitored negative air pressure in relation to surrounding areas, (2)  to  air changes per hour, and (3) discharge of the room air to the outdoors or high­efficiency filtration of the air before it is circulated to other areas in the hospital. The patient must remain in the isolation room with the door closed. Limit the movement in and out of the room and transportation of the patient. When movement is unavoidable, the patient should wear respiratory protection to avoid contamination of other areas within the hospital. Healthcare workers entering the room must wear respiratory protection, such as a personalized, fitted mask with efficient filters (approved particulate respirator).
DROPLET PRECAUTIONS
In addition to standard precautions, use droplet precautions for patients known to have or suspected of having serious illnesses transmitted by large particle droplets (>5 µm). Droplets are generated during talking, sneezing, or coughing and during the performance of procedures. Examples of
,4 infectious agents spread by this method are listed in Table 163­11. TABLE 163­11
Droplet­Spread Infectious Diseases
Invasive Haemophilus influenzae type B (including meningitis, pneumonia, epiglottitis, sepsis)
Invasive Neisseria meningitidis (including meningitis, pneumonia, sepsis)
Serious bacterial respiratory infections
Diphtheria (pharyngeal)
Mycoplasma pneumonia
Pertussis
Pneumonic plague
Streptococcal pharyngitis, pneumonia, scarlet fever
Serious viral infections
Adenovirus
Influenza (including H1N1)
Mumps
Parvovirus B19
Rubella
ISOLATION AND FACEMASKS
Place the patient in a private room when possible. Prioritize patients with excessive cough and sputum production to available single­patient rooms.
Special air handling and ventilation are not required, and the door may remain open. If a private room is not available, the patient may be placed in a room with other patients who have active infections with the same microorganism (i.e., cohorting). If cohorting is also not possible, place a mask on the patient and maintain a spatial separation of at least  ft (1 m) between the infected patient and other patients and visitors. Avoid placing patients with droplet precautions in the same room with patients at increased risk for adverse outcomes from infection. Limit the movement and transportation of patients with droplet precautions. When movement is required, place a facemask on the patient. Healthcare workers should wear facemasks when working within  ft (1 m) of the patient. Healthcare workers should wear respiratory protection equivalent to a fitted N95 filtering respirator or higher level of protection during aerosol­generating procedures such as suctioning. Change protective attire and perform hand hygiene between contacts with all patients.
CONTACT PRECAUTIONS
In addition to standard precautions, use contact precautions when patients are known to have or suspected of having serious illnesses transmitted by
,4 direct patient contact or contact with items in the patient’s environment. Examples of such infectious diseases are listed in Table 163­12. TABLE 163­12
Contact­Spread Infectious Diseases
Multidrug­resistant infections or colonization (GI, respiratory, skin, wound sites)
Enteric infections with low infective dose or prolonged environmental survival
Clostridium difficile
Enterohemorrhagic Escherichia coli O157:H7
Shigella
Hepatitis A
Rotavirus
Respiratory syncytial virus
Parainfluenza virus
Enteroviral infections
Skin infections that are highly contagious or that may occur on dry skin:
Diphtheria (cutaneous)
Herpes simplex virus (neonatal or mucocutaneous)
Impetigo
Major, noncontained abscesses, cellulitis, decubiti
Pediculosis
Scabies
Staphylococcal furunculosis
Herpes zoster (disseminated or in an immunocompromised host)
Viral hemorrhagic conjunctivitis
Viral hemorrhagic infections (Ebola, Lassa, Marburg, Crimean­Congo hemorrhagic fever)
Change gloves whenever the examination and care of a patient result in contact with infectious materials and a high concentration of microorganisms
(wound drainage or fecal material). When expecting contact with infectious materials (incontinence, dressing changes, attention to colostomy), wear a clean, nonsterile gown and gloves. Remove the gown and gloves before leaving the care area. Wash hands with an antimicrobial agent or waterless antiseptic after removal of gloves, and avoid contact with potentially contaminated environmental surfaces or items in the room after hand washing.
Limit transportation and movement of the patient. When movement is required, cover contaminated areas with large, bulky dressings. Bulky, adsorbent, leakproof dressings contain contaminated secretions and limit spread of disease.
Durable, multiuse medical equipment (e.g., blood pressure cuffs, stethoscopes, bedside commodes) should be dedicated to a single patient (or cohort of similarly infected patients). Personal and departmental medical equipment (e.g., stethoscopes, US machines) should be thoroughly cleaned between patient contacts to avoid contamination.
LATEX ALLERGY

Rubber latex is a manufactured polymer that exhibits excellent tensile strength, elasticity, and barrier capacity. Rubber latex is in many medical products, including gloves (for surgery, examination, and housekeeping and cleaning), intravascular devices (balloon catheters, IV tubing, and ports), airway devices (nasopharyngeal airways, endotracheal tubes, and oxygen masks), tourniquets, blood pressure cuffs, ECG leads, tape, and dressings.
REACTIONS TO LATEX
Immune reactions to latex products may take three forms: irritant, contact dermatitis (type IV), and immunoglobulin E (type I).
Irritant reactions are nonimmune in nature and result in dry dermal erythema limited to the site of contact.
Contact dermatitis occurs as a result of dermal exposure to chemicals used in the manufacturing of latex products. This type IV reaction, which may extend beyond the site of contact, results in a dry dermal erythema, pruritus, weeping, and vesiculation. Such loss of skin integrity permits the access of latex proteins to the immune system and may result in an immunoglobulin E–mediated response.
An immunoglobulin E (type I) response is an immunologic reaction to protein allergens contained in latex. Clinical manifestations of such reactions include urticaria, asthma, rhinitis, angioedema, laryngeal edema, and anaphylaxis. Immunoglobulin E reactions may occur because of mucosal, dermal, contact, or inhalational exposure to lubricant powder.
At highest risk of developing immunoglobulin E–mediated latex allergy are those with repeated or chronic exposure to latex and those who are atopic.
Healthcare workers are at increased risk of developing latex allergy due to high­intensity exposure.
LATEX­FREE PRODUCTS AND MINIMIZING LATEX ALLERGY
Many latex­free medical products are available to substitute for common latex products. Prevention of disease in healthcare workers is critical and
,30 requires the use of synthetic or low­allergen powder­free gloves. Healthcare personnel may also use nonlatex gloves for workplace activities that do not involve contact with infectious materials; use synthetic or low­allergen powder­free gloves when handling infectious materials; avoid oil­based hand lotions or creams when wearing latex gloves (to prevent glove deterioration); wash hands with soap and water thoroughly upon removal of latex gloves; frequently clean work areas and equipment contaminated with latex­containing dust; obtain education and training regarding latex allergy; and recognize the symptoms of latex allergy. Hypoallergenic latex gloves do not reduce the risk of latex allergy but do reduce reactions to chemical additives in latex.


