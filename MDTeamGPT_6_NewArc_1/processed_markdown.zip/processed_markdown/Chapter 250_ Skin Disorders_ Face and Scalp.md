## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 250: Skin Disorders: Face and Scalp
Sam Wu; Diana B. McShane; Dean S. Morrell; O. John Ma
INTRODUCTION
Content Update: Leprosy. September 2023
While leprosy is now treatable with multidrug therapy, the disease is still endemic in many countries, including Southeast Asia, the Americas, and
Africa. Recently, it has been identified in Florida and Texas, and is thought to be endemic in those states. Diagnosis can be delayed because many physicians are unaware of the disease. See discussion at the end of disorders discussed under FACE.
This chapter discusses common infections and inflammations affecting the face and scalp; allergic dermatitis involving the face (including poison ivy); and photosensitivity reactions. Erysipelas and facial cellulitis are discussed in Chapter 152, “Soft Tissue Infections,” and impetigo and bullous impetigo are discussed in Chapter 142, “Rashes in Infants and Children.”
FACE
SEBORRHEIC DERMATITIS
Seborrheic dermatitis has both infantile and adult forms. The infantile form is called “cradle cap” and peaks in the first  months of life (see Chapter
142, “Rashes in Infants and Children” for further discussion of infantile seborrheic dermatitis). Adult seborrheic dermatitis presents as white to yellow greasy scaling of the scalp (i.e., dandruff), eyebrows, nasolabial folds, ears, and postauricular skin associated with mild erythema and variable pruritus
(Figure 250­1). Occasionally, the lesions may extend onto the upper central chest and intertriginous areas. Adults with acquired immunodeficiency syndrome and Parkinson’s disease are predisposed to severe disease. The typical distribution of seborrheic dermatitis is in areas with high
 concentrations of sebaceous glands. Malassezia yeasts residing on the skin may contribute to inflammation. This factor may explain why seborrheic dermatitis responds to both antifungal and anti­inflammatory agents. In adults, the condition is chronic and recurrent but without any systemic symptoms.
FIGURE 250­1. Adult seborrheic dermatosis. Erythema and scaling on face and facial skin folds. [Reproduced with permission from Wolff K, Johnson R, Suurmond R:
Fitzpatrick’s Color Atlas & Synopsis of Clinical Dermatology, 5th ed. New York, McGraw Hill, Inc.; 2005:51.]

Chapter 250: Skin Disorders: Face and Scalp, Sam Wu; Diana B. McShane; Dean S. Morrell; O. John Ma 
. Terms of Use * Privacy Policy * Notice * Accessibility
Treat adults with an antidandruff shampoo containing zinc pyrithione, selenium sulfide .5%, salicylic acid, or tar. Ketoconazole can also be used and is available over the counter as 1% shampoo and by prescription at 2% for shampoo and cream. Lather the shampoo into the scalp and leave on briefly before rinsing. For severe cases, a topical corticosteroid such as fluocinonide solution may be applied to the scalp daily. For the face, lowpotency topical corticosteroids applied twice per day may be used (Table 250­1). The use of higher potency topical corticosteroids on the face for more than a few days can lead to the development of perioral dermatitis or steroid rosacea and should be avoided.
Treatment continues until the dermatitis is cleared. Re­treat recurrences as needed.
TABLE 250­1
Clinical Features and Treatment of Seborrheic Dermatitis of the Face, Tinea Barbae, Sycosis Barbae
Condition Clinical Features Treatment Comments
Seborrheic White to yellow scale involving scalp, eyebrows, OTC antidandruff Leave shampoos on for 3–5 minutes before rinsing dermatitis nasolabial folds, and chest with variable erythema and shampoo pruritus Ketoconazole 2% shampoo
Ketoconazole 2% cream
Desonide .05% or hydrocortisone .5%
Tinea Scaly erythematous plaques, follicular pustules, or Griseofulvin, microsize Avoid griseofulvin and terbinafine in patients with barbae erythematous boggy plaques in beard distribution; 500 milligrams PO known hepatic disease; reasonable to obtain baseline associated with loosened/broken hairs daily for  weeks liver function tests when prescribing
Griseofulvin, ultramicrosize 375 milligrams PO daily for
 weeks
Terbinafine 250 milligrams daily for 2–
 weeks
Sycosis Follicular pustules and perifollicular erythema in Warm compresses barbae beard distribution Mupirocin 2% ointment
Oral antistaphylococcal antibiotics
Abbreviation: OTC = over the counter.
TINEA BARBAE AND SYCOSIS BARBAE
Tinea barbae is a dermatophyte infection involving the beard area of the face and neck and occurs in postpubertal males. The cause is usually the
 genus Trichophyton. Predisposing factors to tinea barbae include use of topical steroids, contact with infected pets, and diabetes mellitus. Sycosis barbae is a deep folliculitis within the beard area with perifollicular inflammation. The causative agent is usually Staphylococcus aureus.
In tinea barbae, severe inflammatory plaques and follicular pustules occur in the beard area (Figure 250­2). Kerion­like lesions can develop as well as abscesses and sinus tracts. Hairs are usually loosened or broken off.
FIGURE 250­2. Tinea barbae. [Photo contributed by University of North Carolina Department of Dermatology.]
In sycosis barbae, discrete pustules, usually involving S. aureus, with perifollicular inflammation are evident (Figure 250­3). Unlike tinea barbae, the hairs are usually not loosened or broken off.
FIGURE 250­3. Sycosis barbae. [Photo contributed by University of North Carolina Department of Dermatology.]
The diagnosis is clinical, but tinea barbae sometimes can resemble acne vulgaris or bacterial folliculitis. A potassium hydroxide preparation or fungal culture can be done to confirm the diagnosis. Permanent alopecia and scarring can result if left untreated.
Treatment of tinea barbae requires oral antifungals. Microsize griseofulvin, 500 milligrams PO daily, or ultramicrosize griseofulvin, 375 milligrams
PO daily, for  weeks can be used. Terbinafine 250 milligrams PO daily for  to  weeks can also be used; both griseofulvin and terbinafine should be avoided in patients with known hepatic dysfunction (Table 250­1). Supportive care includes shaving or depilating the hair and warm compresses to remove the crust.
For sycosis barbae, initial treatment with warm compresses and mupirocin ointment may be sufficient. If lesions are chronic, treatment usually requires systemic antibiotics with adequate S. aureus coverage (Table 250­1).
HERPES ZOSTER INFECTION
Herpes zoster or “shingles” is a cutaneous manifestation of reactivation of varicella­zoster virus from its latent state in neural ganglia following primary infection. For discussion of other manifestations of varicella­zoster virus infection, see Chapter 154, “Serious Viral Infections.”
Pain or dysesthesia typically precedes cutaneous findings of herpes zoster by  to  days. Erythematous papules progress to clusters of vesicles and pustules on an erythematous base in a dermatomal distribution (Figure 250­4). Vesicles crust over in about  week. While zoster typically involves the thoracic and lumbar dermatomes, presence of lesions within the ophthalmic branch (V1) of the trigeminal nerve and especially on the tip of the nose is concerning for herpes zoster ophthalmicus, which requires emergent ophthalmology evaluation. Ramsay Hunt syndrome results from reactivation of varicella­zoster virus in the geniculate ganglion and presents with ear pain, vesicles in the external auditory canal, facial nerve paralysis, and
 vestibulocochlear dysfunction.
FIGURE 250­4. A. Herpes zoster in trigeminal nerve distribution. Note the lesion on the tip of the nose, which suggests nasociliary branch involvement. B.
Dermatomes of the head and neck. Cev = cervical; gr = greater; N = nerve, Sm = smaller [A. Reproduced with permission from Fleischer A Jr, Feldman S,
McConnell C, et al: Emergency Dermatology: A Rapid Treatment Guide. New York: McGraw­Hill, Inc.; 2002, p. 157. B. Reproduced with permission from
Wolff K, Johnson R, Suurmond R: Fitzpatrick’s Color Atlas & Synopsis of Clinical Dermatology, 5th ed. New York: McGraw­Hill, Inc.; 2005.]
The key to diagnosis is the unilateral distribution and pronounced pain in the area of involvement. Diagnosis can be confirmed by polymerase chain reaction analysis of swabs taken from the base of an intact vesicle. Tzanck smear can also demonstrate multinucleated giant cells, but unlike polymerase chain reaction, it cannot differentiate between varicella­zoster virus, herpes simplex virus , or herpes simplex virus  infection.
Treatment is most effective if it is initiated within the first  hours of symptoms and decreases healing time, new lesion formation, and the risk of postherpetic neuralgia. Treatment options in an immunocompetent patient include oral acyclovir or valacyclovir (Table 250­2). In immunocompromised patients, intravenous acyclovir is necessary. Local care can be provided with aluminum acetate compresses three times daily followed by antibiotic ointment to prevent secondary bacterial infection. Assess and treat associated pain, which may be severe. Vaccination against
 zoster reduces the incidence and severity of illness as well as risk of postherpetic neuralgia and is indicated for adults over the age of . TABLE 250­2
Clinical Features and Treatment of Herpes Zoster and Herpes Simplex
Condition Clinical Features Treatment Options Comments
Herpes Vesicles and pustules on erythematous base in Acyclovir: 800 milligrams PO  Treatment should be initiated within the first zoster dermatomal distribution; associated pain, pruritus, times a day for  d  h after symptom onset, if possible dysesthesia Valacyclovir: 1000 milligrams PO  times a day for  d
Herpes Asymptomatic infection or painful vesicles and Acyclovir: 400 milligrams PO  Can extend treatment of acyclovir or simplex, ulcers with surrounding erythema on mucosa times a day for 7–10 d or 200 valacyclovir if not healed after  d initial associated with fevers, malaise, lymphadenopathy milligrams PO  times a day for 7– episode  d
Valacyclovir: 1000 milligrams PO twice a day for 7–10 d
Herpes Recurrent painful vesicles at or near site of primary Acyclovir: 400 milligrams PO  Avoid triggers: ultraviolet exposure, trauma, simplex, infection preceded by prodrome of pruritus or times a day for  d or 800 stress, illness; may require referral to recurrence dysesthesia milligrams PO twice a day for  d dermatology for suppression of frequent
Valacyclovir: 2000 milligrams PO flares twice a day for  d
Patients with herpes zoster are contagious to nonvaccinated individuals without natural immunity, and isolation is needed for patients suspected of the disease at triage. Patients should be instructed to cover all open areas when visiting the physician at follow­up.
HERPES SIMPLEX VIRUS INFECTIONS
Herpes simplex virus type  most commonly occurs on the face. Primary infection occurs during childhood or adolescence and is typically asymptomatic but occasionally presents with painful orofacial vesicular lesions associated with systemic symptoms. Recurrences tend to be milder and occur primarily on the lips, nose, and oral cavity.
The typical lesions of herpes simplex virus are painful, grouped vesicles on an erythematous base (Figure 250­5). The characteristic primary eruption is a gingivostomatitis with herpetic lesions on the lips and in the oral cavity that may persist for weeks accompanied by fever and malaise. Recurrences may be induced by ultraviolet light, fever, stress, or local trauma and typically present as herpes labialis (“fever blisters” or “cold sores”). Individuals often experience a prodrome of localized tingling or burning several hours before the onset of the eruption. The herpetic lesion usually occurs along the lip margin and completely heals within  days.
FIGURE 250­5. Herpetic gingivostomatitis. [Photo contributed by University of North Carolina Department of Dermatology.]
In patients with underlying atopic dermatitis, a severe form of herpesvirus infection can occur called eczema herpeticum in which herpes simplex virus or varicella­zoster virus can infect active atopic dermatitis lesions (see Chapter 142, “Rashes in Infants and Children”).

Treatment for primary herpes simplex virus gingivostomatitis works best when given within the first  hours (Table 250­2). Treatment can continue for up to  days if lesions have not crusted. Immunocompromised patients with severe involvement require hospitalization for IV acyclovir.

Suppressive treatment with acyclovir or valacyclovir can decrease outbreaks of herpes labialis. Patients with recurrent disease should be instructed to avoid triggers, especially the sun, by using sunscreen and a lip balm with ultraviolet light protection.
LEPROSY
Leprosy, a disease that has been monitored and described for thousands of years, remains a chronic infectious disease that impacts over 150 countries worldwide. It may lead to significant physical disfigurement and impairment if left untreated. Fewer than 200 cases are reported annually in the United States, although several cases have been reported in Florida and Texas in the spring and summer of 2023. This suggests that leprosy may now be endemic in Florida and other states in southeastern United States. Some patients demonstrated no risk factors, such as known exposure or travel abroad to places where leprosy is endemic.
Mycobacterium leprae is responsible for this chronic infectious disease. Leprosy is transmitted through oral secretions and nasal droplets after prolonged contact with an infected individual. It is not transmitted by casual contact. Humans are the primary reservoir for Mycobacterium leprae; armadillos are the only other confirmed source.
Leprosy is typically classified by type and number of skin areas affected: paucibacillary (≤  skin lesions with no bacteria detected on samples from those areas) and multibacillary (≥  skin lesions, bacteria detected on samples from skin lesions, or both).
Symptoms progress very slowly and typically do not begin to appear until at least  year after infection. Dermatologic features include hypoesthetic, centrally hypopigmented macules with sharp, raised borders; nodular and papular lesions affecting the face or earlobes; plantar ulcers on the soles of the feet; and loss of eyebrows or eyelashes. Peripheral neuropathy may affect the areas of the skin lesions. This can lead to permanent deterioration of the ability to sense pain and temperature. Some patients may also be afflicted with iritis or corneal
 insensitivity.
Leprosy is primarily a clinical diagnosis, which is confirmed by microscopic examination of biopsy specimens taken from the advancing edge of skin lesions. The differential diagnosis includes autoimmune disorders, systemic lupus erythematosus, parasitic infections, vitiligo, cutaneous tuberculosis, and a variety of hypochromic skin lesions. Treatment in the ED begins with providing a mask to patients with suspected leprosy, placement in respiratory isolation. Consult an Infectious Disease specialist to assist with the confirmation of the diagnosis and management. A multidrug regimen of dapsone, rifampin, and clofazimine is used to treat leprosy. Once patients are taking antibiotics, they are no longer contagious.
The antibiotic regimen will help stop disease progression but will not reverse physical deformities or nerve damage.
SCALP
DISSECTING CELLULITIS OF THE SCALP
Dissecting cellulitis of the scalp is an intense inflammatory and scarring disease of the scalp and neck, driven by follicular occlusion and often complicated by secondary bacterial infection. It occurs most commonly in young men of African descent and consists of boggy tender nodules in
 multiple areas of the scalp and the neck (Figure 250­6). Osteomyelitis of the skull has been reported as a sequela. The nodules suppurate and develop interconnecting, draining sinus tracts. Hair loss develops over these nodules, and permanent scarring, alopecia, and keloids can occur. ED therapy includes antibacterial washes, such as chlorhexidine, which is available without prescription, and oral antibiotics such as doxycycline and minocycline (Table 250­3). Incision and drainage of individual suppurative nodules does not treat the underlying condition but may provide symptomatic relief. Refer to a dermatologist for continued management. Dapsone, intralesional corticosteroids, and prednisone have variable efficacy in treating this challenging condition. Isotretinoin, surgical excision, laser treatment, and tumor necrosis factor­α blockers have also been used
 successfully.
FIGURE 250­6. Dissecting cellulitis of the scalp. [Photo contributed by University of North Carolina Department of Dermatology.]
TABLE 250­3
Clinical Features and Treatment of Pediculosis Capitis, Tinea Capitis, and Dissecting Cellulitis of Scalp
Condition Clinical Features Treatment Comments
Dissecting Tender, suppurative nodules Over­the­counter antibacterial wash, doxycycline or Due to chronic condition, referral to cellulitis of and sinus tracts associated with minocycline 100 milligrams PO twice a day; incision and dermatology recommended scalp scarring and alopecia drainage for painful, fluctuant nodules
Tinea Scalp pruritus, broken hairs, Griseofulvin, microsized 20–25 milligrams/kg/d PO (<1 May be associated with id reaction or capitis alopecia, and lymphadenopathy gram/d) for  wk or kerion formation; treatment duration may
Griseofulvin, ultramicrosized 15–20 milligrams/kg/d PO be extended based on response
(<750 milligrams/d) for  wk or
Terbinafine 125–250 milligrams/d PO for  wk
Pediculosis Scalp pruritus (especially behind Permethrin cream, pyrethrin lotion, ivermectin lotion, or Machine wash and dry recently used capitis ears), presence of adult lice malathion cream; repeat treatment in 7–10 d clothing and bed linens
(head lice) and/or nits along hair shaft
TINEA CAPITIS
Tinea capitis is a dermatophyte infection of the scalp. Causative agents are usually from the genus Trichophyton. The fungi invade the hair shaft and stratum corneum of the skin.
Clinically, there are nonscarring patches of alopecia with broken hairs and scale at the periphery. Occasionally, there is intense inflammation, with a boggy, tender, indurated plaque with superficial pustules and overlying alopecia (Figure 250­7). This reaction, referred to as a kerion, may result in permanent scarring and alopecia. Cervical and/or occipital lymphadenopathy may be present. In some cases of tinea capitis, especially after initiation of oral antifungal therapy, patients will mount an immune response to the dermatophyte, called an id reaction, at distant sites. This id reaction appears as widespread, symmetric, pruritic, monomorphic, eczematous papules and responds to topical steroids. Development of an id reaction does not require discontinuation of antifungal therapy.
FIGURE 250­7. A. Tinea capitis with Wood’s light fluorescence. B. Kerion. [Photo contributed by University of North Carolina Department of Dermatology.]
Diagnosis is mainly clinical. Wood’s lamp examination (Table 250­4) is not helpful because more than 90% of cases of tinea capitis are due to
Trichophyton species, which do not fluoresce.
TABLE 250­4
Fluorescence From Wood’s Lamp
Nits
Lice
Microsporum
Malassezia
If necessary, diagnosis can be confirmed by a positive potassium hydroxide preparation or positive fungal culture. Scraping only the scalp rarely gives a positive potassium hydroxide examination because Trichophyton species invade the hair shaft. If fungal culture is necessary to establish or confirm the diagnosis, it usually takes  to  weeks for the culture to grow. A positive culture will help to exclude other conditions such as atopic dermatitis or seborrheic dermatitis.
Topical treatment alone is not effective for tinea capitis. The current first­line therapy is oral griseofulvin or terbinafine. Higher doses of griseofulvin are needed to treat Trichophyton species, which represent the most common cause of tinea capitis. Ultramicrosize griseofulvin or liquid microsize griseofulvin for those who cannot swallow pills is an effective treatment (Table 250­3). Treat for a minimum of  weeks, and then reevaluate to determine whether therapy should be continued. Alternatively, treatment with weight­based terbinafine dosing can be used. To decrease contagiousness and scale, patients should also wash hair with antifungal shampoo (ketoconazole 2% or selenium sulfide .5%) three times per week for the first  weeks of therapy.
Other family members, especially children, and other close contacts, such as classmates at school or day care, should be evaluated. Other affected members should be treated simultaneously to prevent reinfection. If Microsporum is diagnosed by culture, pets (cats and dogs) should be examined by a veterinarian. Follow­up with a primary care provider or dermatologist is crucial, because persistent infection may manifest only as scale and go unrecognized by caregivers.
HEAD LICE (PEDICULOSIS CAPITIS)
Head lice, or pediculosis capitis, is a common worldwide infestation that usually occurs in children age  to  years, but can occur at any age. It is caused by the head louse, Pediculus capitis, which is approximately  to  mm in size. Lice need a blood meal every  to  hours and live for  days while laying numerous eggs. Adult lice cannot survive more than  hours without a blood meal. The eggs are cemented to the hair by a proteinaceous matrix (Figure 250­8). Transmission occurs by head­to­head contact and by brushes and combs.
FIGURE 250­8. Head lice. [Photo contributed by the Department of Dermatology, University of North Carolina.]
Head lice are limited to the scalp, behind the ears, and on the back of the neck. Intense pruritus is a feature. Diagnosis is made by identification of nits and/or adult lice in the scalp hair. Nits are oval, gray­white egg capsules. If all nits are located >7 mm from the scalp surface, active infestation is unlikely. Nits and lice fluoresce with a Wood’s lamp (Table 250­4).
Topical application of permethrin cream (1% or 5%) is the first­line treatment. Apply to the hair, leave on overnight, and rinse off in the morning (Table
250­3). Alternatively, pyrethrin cream or ivermectin lotion can be applied for  minutes and then rinsed off. Malathion .5% cream is another alternative and is applied to the scalp overnight, but malathion is flammable and should not be used in children less than  years old.
Application of thick moisturizing creams to hair followed by drying with a blow dryer has also been used for resistant cases. Repeat treatment in  to  days is recommended for the above therapeutic options. Children with head lice do not need to be removed from school, because “no­nit” policies
 have been shown to be excessive.
POISON IVY/OAK, OTHER ALLERGIC CONTACT DERMATITIS, AND PHOTOSENSITIVITY
Two types of contact allergies are likely to result on the face. The first is the result of an aerosolized allergen. The second is due to direct physical contact that is most prominent on the sensitive parts of the face.
POISON IVY AND POISON OAK/SUMAC
About 70% of individuals are sensitized to poison ivy, oak, or sumac. Involvement of the face can be through aerosolization or direct contact with the plant.
Exposure to aerosolized poison ivy or oak presents as erythema and scale with or without vesiculation (Figure 250­9). The involvement is diffuse, with upper and lower eyelids affected. Aerosolization can occur if plants are burned or from activities that can cause the toxic urushiols to become airborne, such as using a weed wacker or lawnmower in a poison ivy patch. Direct contact from plants or contaminated clothing results in the typical linear lesions with vesicle and bullae formation.
FIGURE 250­9. Poison ivy. [Photo contributed by University of North Carolina Department of Dermatology.]
Treatment is prednisone, .5 milligram/kg/d for  to  weeks. Washing with water, alcohol, or Tecnu® can help remove the urushiol.
OTHER ALLERGIC CONTACT DERMATITIS
Examples of common direct contactants affecting the face include nickel, nail polishes, toothpaste, preservatives in makeup, contact lens solutions, eyeglasses, and hair care products. Chemical­splash injuries are a common cause of facial irritant contact dermatitis. A thorough history is necessary to uncover the offending agent. Referral to a dermatologist may be necessary if the history is unrevealing. This distribution is in contrast with photosensitive eruptions in which non–sun­exposed areas, such as the upper eyelids and the upper lip, are spared (see Figure 250­10). Direct allergic contact dermatitis tends to be most prominent on the most sensitive skin, such as the eyelids.
Medical treatment is of little value if the offending agent is not removed from the patient’s environment. Depending on the severity, topical or oral corticosteroids and oral antihistamines are used. Aluminum acetate (Burow’s solution, available commercially as Domeboro®) compresses can be beneficial as well. Short duration (3 to  days) of medium­ to high­potency topical corticosteroids can be used on the face (Table 250­5). Often, extensive and severe periocular involvement requires oral prednisone. See Chapter 253, “Skin Disorders: Extremities” for further discussion of treatment of poison ivy, oak, or sumac.
TABLE 250­5
Clinical Features and Treatment of Poison Ivy or Oak, Allergic Contact Dermatitis, and Photosensitivity
Condition Clinical Features Treatment Comments
Poison ivy/oak Pruritic, linear, erythematous, edematous plaques with vesicles Oral antihistamines Severe cases may require and excoriations Clobetasol .05%, fluocinonide oral prednisone
.05%, or other high­potency topical steroids
Prednisone .5 milligram/kg/d for  to  wk
Direct contact Pruritic, scaly, erythematous papules and plaques with or Identification and avoidance of Severe cases may require allergens without vesicles in distribution suggestive of exposure allergen oral prednisone
Mid­ to high­potency topical steroids such as triamcinolone .1% or fluocinonide .05%
Photosensitivity Sunburn­like erythema (phototoxic) or pruritic erythematous Photoprotection See Table 250­6 for list of papules and plaques with or without vesicles (photoallergic) in Identification and avoidance of common photosensitizing sun­exposed distribution photosensitizer medications
PHOTOSENSITIVITY
Photosensitivity is suspected when exposure to ultraviolet light either exacerbates or directly causes certain conditions. Examples of the former include lupus erythematosus, dermatomyositis, porphyria cutanea tarda, dermatitis of niacin deficiency (pellagra), and recurrences of herpes simplex virus. Examples of the latter include exogenous photosensitivity disorders and the sunburn reaction (see Chapter 217, “Thermal Burns”).
Exogenous photosensitivity disorders result from topical application or ingestion of agents that increase the sensitivity of skin to ultraviolet light.
Photosensitivity disorders may be phototoxic or photoallergic. Phototoxic reactions occur quickly and appear similar to a sunburn and are thought to be due to direct damage to keratinocytes by UV radiation. Photoallergic reactions occur later and exhibit eczema­like changes in the skin with vesiculation (Figure 250­10). Photoallergic reactions are a form of delayed­type hypersensitivity reaction to an allergen formed in the skin after exposure to ultraviolet radiation.
FIGURE 250­10. Photosensitivity reaction. [Photo contributed by University of North Carolina Department of Dermatology.]
Topical photosensitizers usually result in a cutaneous eruption at the sites of application. Subsequent ultraviolet light exposure is necessary for the eruption to occur. Phytophotodermatitis refers to a topical phototoxic dermatitis due to plants, most commonly caused by a group of chemicals called furocoumarins that are found in lime juice, fragrances, figs, celery, and parsnips. Table 250­6 lists several ingested substances that can result in a photosensitivity eruption.
TABLE 250­6
Medications Commonly Causing Photosensitivity Eruptions
Phototoxic Photoallergic
Chlorpromazine NSAIDs
Furosemide Griseofulvin
Tetracyclines (demeclocycline > doxycycline) Sulfonamides
Thiazides Para­aminobenzoic acid and most sunscreens
Psoralen Promethazine
Coal tar Psoralen
Amiodarone Sulfonylureas (glipizide, glyburide)
Isotretinoin Fragrances
Fluoroquinolones Dapsone
History and distribution of the eruption can assist in photosensitivity disorders. Often a linear or spray pattern suggests that an externally applied substance is the culprit. Because photosensitizing medications are ingested and distributed throughout the body, the eruption can involve all sunexposed areas. The characteristic distribution of a photosensitivity eruption is the face, posterior neck, dorsal hands, and extensor arms. Certain areas, including the creases of the eyelids, upper lip, submental anterior neck, and postauricular neck, are spared.
Photopatch testing performed by a dermatologist or allergist may be helpful in identifying the photosensitizing agent. If the diagnosis is unclear, other photosensitivity disorders, such as lupus erythematosus, dermatomyositis, and polymorphous light eruption, should be excluded.
The most important part of treatment of sunburn and photosensitivity is prevention. Sun avoidance, liberal use of sunscreen (ultraviolet A and B protection with sun protection factor of at least 30) with frequent reapplications, and use of sun­protective clothing are recommended.
In cases of photosensitivity, discontinue the causative agent. Initial management includes topical corticosteroids, and management similar to a sunburn reaction. The patient should avoid the sun until the eruption has cleared completely.


